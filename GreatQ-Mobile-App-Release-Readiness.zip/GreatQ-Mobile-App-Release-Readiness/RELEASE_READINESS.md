# GreatQ release readiness

**Status: not ready for store submission yet.** The app and admin portal build and run, but several release inputs are still missing.

## Verified

- Workspace TypeScript checks pass.
- The GreatQ Expo preview renders, and the admin portal renders at `/greatq-admin/`.
- The API health check and question catalog both return HTTP 200.
- The development database schema is present.
- The owner-provided iOS bundle identifier and Android package name are set in `artifacts/past-questions/app.json`.
- Admin imports preview existing and in-file duplicates before import; the API skips duplicates during the write.
- Expired unsubmitted attempts are removed periodically after the timer and network grace period.
- Expo Doctor passed all 21 checks; the Expo dependency check passed.
- The admin portal production build succeeds.

## Required before release

1. **Load approved question content.** The current catalog contains zero exams, subjects, and questions. Only import content GreatQ has permission to distribute.
2. **Enable admin uploads securely.** `ADMIN_UPLOAD_TOKEN` is not configured in Replit Secrets. The admin portal cannot add content until it is set. Do not put the token in source code or commit it.
3. **Complete store materials.** Prepare the privacy policy, support contact, store description, age/content rating, and required screenshots.
4. **Test native builds.** The browser preview verifies the web rendering, not a real iPhone or Android install, device permissions, or store-signed binaries.
5. **Confirm production API configuration.** Ensure the released app points to the published API and production database, not the development domain or development data.

Replit's current Expo publishing flow supports uploading to App Store Connect. It can build for Android, but publishing to Google Play is not currently supported through that flow.

## Recommended improvements

- Replace the shared upload token with named staff accounts and an audit trail before a wider admin rollout.
- Progress history is stored on each device. Clearly communicate this, and consider optional account-based sync for students who use multiple devices.

## Non-blocking development note

The Expo workflow still reports a missing GTK library while trying to launch React Native DevTools. Metro, the Expo preview, and the app itself continue to run; this does not block a store build.
