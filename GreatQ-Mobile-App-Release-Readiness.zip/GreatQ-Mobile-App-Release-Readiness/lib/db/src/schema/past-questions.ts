import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import {
  check,
  foreignKey,
  index,
  integer,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const pqExamsTable = pgTable(
  "pq_exams",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
  },
  (table) => [uniqueIndex("pq_exams_name_unique").on(table.name)],
);

export const pqSubjectsTable = pgTable(
  "pq_subjects",
  {
    id: serial("id").primaryKey(),
    examId: integer("exam_id")
      .notNull()
      .references(() => pqExamsTable.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    durationMin: integer("duration_min").notNull().default(30),
  },
  (table) => [
    uniqueIndex("pq_subjects_exam_name_unique").on(table.examId, table.name),
  ],
);

export const pqQuestionsTable = pgTable(
  "pq_questions",
  {
    id: serial("id").primaryKey(),
    subjectId: integer("subject_id")
      .notNull()
      .references(() => pqSubjectsTable.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    optionA: text("option_a").notNull(),
    optionB: text("option_b").notNull(),
    optionC: text("option_c").notNull(),
    optionD: text("option_d").notNull(),
    answer: text("answer").notNull(),
    explanation: text("explanation"),
    year: integer("year"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    check(
      "pq_questions_answer_check",
      sql`${table.answer} in ('A', 'B', 'C', 'D')`,
    ),
    index("pq_questions_subject_year_idx").on(table.subjectId, table.year),
    index("pq_questions_subject_normalized_body_idx").on(
      table.subjectId,
      sql`lower(btrim(regexp_replace(${table.body}, '[[:space:]]+', ' ', 'g')))`,
    ),
  ],
);

export const pqAttemptsTable = pgTable(
  "pq_attempts",
  {
    id: text("id").primaryKey(),
    subjectId: integer("subject_id")
      .notNull()
      .references(() => pqSubjectsTable.id),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
    durationSeconds: integer("duration_seconds").notNull(),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    score: integer("score"),
    total: integer("total").notNull(),
  },
  (table) => [
    index("pq_attempts_subject_idx").on(table.subjectId),
    index("pq_attempts_unsubmitted_started_idx")
      .on(table.startedAt)
      .where(sql`${table.submittedAt} is null`),
  ],
);

export const pqAttemptQuestionsTable = pgTable(
  "pq_attempt_questions",
  {
    attemptId: text("attempt_id").notNull(),
    questionId: integer("question_id").notNull(),
    position: integer("position").notNull(),
    selectedAnswer: text("selected_answer"),
  },
  (table) => [
    primaryKey({
      columns: [table.attemptId, table.questionId],
      name: "pq_attempt_questions_pk",
    }),
    foreignKey({
      columns: [table.attemptId],
      foreignColumns: [pqAttemptsTable.id],
      name: "pq_attempt_questions_attempt_fk",
    }).onDelete("cascade"),
    foreignKey({
      columns: [table.questionId],
      foreignColumns: [pqQuestionsTable.id],
      name: "pq_attempt_questions_question_fk",
    }).onDelete("cascade"),
    uniqueIndex("pq_attempt_questions_position_unique").on(
      table.attemptId,
      table.position,
    ),
    index("pq_attempt_questions_question_idx").on(table.questionId),
  ],
);

export const insertPqExamSchema = createInsertSchema(pqExamsTable).omit({
  id: true,
});
export const insertPqSubjectSchema = createInsertSchema(pqSubjectsTable).omit({
  id: true,
});
export const insertPqQuestionSchema = createInsertSchema(pqQuestionsTable).omit({
  id: true,
  createdAt: true,
});
export const insertPqAttemptSchema = createInsertSchema(pqAttemptsTable);
export const insertPqAttemptQuestionSchema = createInsertSchema(
  pqAttemptQuestionsTable,
);

export type InsertPqExam = z.infer<typeof insertPqExamSchema>;
export type InsertPqSubject = z.infer<typeof insertPqSubjectSchema>;
export type InsertPqQuestion = z.infer<typeof insertPqQuestionSchema>;
export type InsertPqAttempt = z.infer<typeof insertPqAttemptSchema>;
export type InsertPqAttemptQuestion = z.infer<
  typeof insertPqAttemptQuestionSchema
>;
export type PqExam = typeof pqExamsTable.$inferSelect;
export type PqSubject = typeof pqSubjectsTable.$inferSelect;
export type PqQuestion = typeof pqQuestionsTable.$inferSelect;
export type PqAttempt = typeof pqAttemptsTable.$inferSelect;
export type PqAttemptQuestion = typeof pqAttemptQuestionsTable.$inferSelect;

