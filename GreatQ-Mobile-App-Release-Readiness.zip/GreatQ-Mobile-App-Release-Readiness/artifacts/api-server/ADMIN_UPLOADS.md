# GreatQ Admin question uploads

The GreatQ Admin page at `/greatq-admin/` lets staff validate a CSV file and add
questions to the shared bank. Before import, the page sends the batch to
`POST /api/admin/imports/preview` and shows existing and in-file duplicates.
The final `POST /api/admin/imports` request skips duplicates again on the server,
so repeated or concurrent imports do not add the same question content twice.
Trusted admin services can call either endpoint with the same authorization
token. The mobile catalog refreshes automatically.

Enter the `ADMIN_UPLOAD_TOKEN` stored in Replit Secrets in the password field on
the admin page. It is held in browser memory only and sent as a bearer token.
Never put the token in source code, a mobile build, or local storage.

CSV files need these columns:

```text
body,option_a,option_b,option_c,option_d,answer
```

`explanation` and `year` are optional. Each batch can contain up to 500
questions, with import requests limited to 10 MB. Select the exam, subject, and
time limit in the admin page before importing. The page includes a downloadable
CSV template and reports row-specific validation errors.

```http
POST /api/admin/imports
Authorization: Bearer <ADMIN_UPLOAD_TOKEN>
Content-Type: application/json
```

Example request:

```json
{
  "examName": "Faculty of Science · 2025",
  "subjectName": "Biology",
  "durationMin": 30,
  "questions": [
    {
      "body": "Which organelle is known as the powerhouse of the cell?",
      "options": {
        "A": "Nucleus",
        "B": "Ribosome",
        "C": "Mitochondrion",
        "D": "Vacuole"
      },
      "answer": "C",
      "explanation": "Mitochondria release energy from food through respiration.",
      "year": 2025
    }
  ]
}
```

Question identity is based on the normalized question text and all four ordered
answer options within the named subject. Letter case and repeated whitespace do
not create a second copy; answer keys, explanations, and years do not change
identity. The preview response includes duplicate CSV row numbers and indicates
whether a row already exists in the question bank or repeats an earlier CSV row.

Send question material the institution or uploader is authorized to distribute.
