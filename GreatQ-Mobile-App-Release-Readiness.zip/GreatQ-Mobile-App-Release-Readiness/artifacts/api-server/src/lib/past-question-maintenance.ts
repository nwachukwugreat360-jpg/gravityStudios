import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { logger } from "./logger";

const CLEANUP_INTERVAL_MS = 15 * 60 * 1000;
const CLEANUP_BATCH_SIZE = 500;

async function deleteExpiredAttempts(): Promise<number> {
  let totalDeleted = 0;

  while (true) {
    const result = await db.execute(sql`
      WITH expired_attempts AS (
        SELECT id
        FROM pq_attempts
        WHERE submitted_at IS NULL
          AND started_at
            + (duration_seconds * INTERVAL '1 second')
            + INTERVAL '30 seconds' < now()
        ORDER BY started_at
        LIMIT ${CLEANUP_BATCH_SIZE}
        FOR UPDATE SKIP LOCKED
      )
      DELETE FROM pq_attempts AS attempt
      USING expired_attempts
      WHERE attempt.id = expired_attempts.id
      RETURNING attempt.id
    `);

    const deletedCount = result.rowCount ?? 0;
    totalDeleted += deletedCount;
    if (deletedCount < CLEANUP_BATCH_SIZE) return totalDeleted;
  }
}

export function startPastQuestionMaintenance(): void {
  let cleanupRunning = false;

  const runCleanup = async (): Promise<void> => {
    if (cleanupRunning) return;
    cleanupRunning = true;
    try {
      const deletedCount = await deleteExpiredAttempts();
      if (deletedCount > 0) {
        logger.info(
          { deletedCount },
          "Removed expired unsubmitted quiz attempts",
        );
      }
    } catch (error) {
      logger.error({ err: error }, "Failed to clean up expired quiz attempts");
    } finally {
      cleanupRunning = false;
    }
  };

  void runCleanup();
  const timer = setInterval(() => void runCleanup(), CLEANUP_INTERVAL_MS);
  timer.unref();
}
