import { Router, type IRouter } from "express";
import healthRouter from "./health";
import pastQuestionsRouter from "./past-questions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(pastQuestionsRouter);

export default router;
