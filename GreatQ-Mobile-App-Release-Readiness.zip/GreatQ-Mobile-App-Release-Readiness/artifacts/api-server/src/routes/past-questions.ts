import { timingSafeEqual, randomUUID } from "node:crypto";
import { Router, type IRouter, type RequestHandler } from "express";
import {
  and,
  asc,
  count,
  eq,
  inArray,
  isNotNull,
  isNull,
  max,
  sql,
} from "drizzle-orm";
import {
  db,
  pqAttemptQuestionsTable,
  pqAttemptsTable,
  pqExamsTable,
  pqQuestionsTable,
  pqSubjectsTable,
} from "@workspace/db";
import {
  GetAttemptParams,
  GetAttemptResponse,
  GetAttemptResultParams,
  GetAttemptResultResponse,
  GetCatalogResponse,
  CreateAdminSubjectBody,
  CreateAdminSubjectResponse,
  ImportQuestionsBody,
  ImportQuestionsResponse,
  PreviewQuestionImportBody,
  PreviewQuestionImportResponse,
  StartAttemptBody,
  StartAttemptResponse,
  SubmitAttemptBody,
  SubmitAttemptParams,
  SubmitAttemptResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const QUESTION_IMPORT_LOCK_NAMESPACE = 18_427;

type ParsedQuestionImport = ReturnType<typeof ImportQuestionsBody.parse>;
type ImportQuestion = ParsedQuestionImport["questions"][number];
type ExistingImportQuestion = {
  body: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
};

function normalizedQuestionText(value: string): string {
  return value.trim().replace(/\s+/g, " ").toLowerCase();
}

function normalizedQuestionBodySql() {
  return sql<string>`lower(btrim(regexp_replace(${pqQuestionsTable.body}, '[[:space:]]+', ' ', 'g')))`;
}

function questionContentKey(question: {
  body: string;
  options: { A: string; B: string; C: string; D: string };
}): string {
  return JSON.stringify([
    question.body,
    question.options.A,
    question.options.B,
    question.options.C,
    question.options.D,
  ].map(normalizedQuestionText));
}

function classifyQuestionDuplicates(
  questions: ImportQuestion[],
  existingQuestions: ExistingImportQuestion[],
) {
  const existingKeys = new Set(
    existingQuestions.map((question) =>
      questionContentKey({
        body: question.body,
        options: {
          A: question.optionA,
          B: question.optionB,
          C: question.optionC,
          D: question.optionD,
        },
      }),
    ),
  );
  const firstCsvRowByKey = new Map<string, number>();
  const duplicates: Array<{
    rowNumber: number;
    duplicateOfRow: number | null;
    source: "question_bank" | "csv";
  }> = [];

  questions.forEach((question, index) => {
    const rowNumber = index + 2;
    const key = questionContentKey(question);
    const firstCsvRow = firstCsvRowByKey.get(key);
    if (firstCsvRow !== undefined) {
      duplicates.push({
        rowNumber,
        duplicateOfRow: firstCsvRow,
        source: "csv",
      });
    } else if (existingKeys.has(key)) {
      duplicates.push({
        rowNumber,
        duplicateOfRow: null,
        source: "question_bank",
      });
    }
    firstCsvRowByKey.set(key, rowNumber);
  });

  return {
    duplicates,
    newQuestionCount: questions.length - duplicates.length,
  };
}

function importValidationError(data: ParsedQuestionImport): string | null {
  if (!data.examName.trim() || !data.subjectName.trim()) {
    return "Exam and subject names cannot be blank.";
  }
  const emptyQuestion = data.questions.find(
    (question) =>
      !question.body.trim() ||
      !question.options.A.trim() ||
      !question.options.B.trim() ||
      !question.options.C.trim() ||
      !question.options.D.trim(),
  );
  return emptyQuestion
    ? "Question text and all four answer options are required."
    : null;
}

const requireAdminUploadToken: RequestHandler = (req, res, next) => {
  const expected = process.env.ADMIN_UPLOAD_TOKEN;
  if (!expected) {
    res.status(503).json({ error: "Admin uploads are not configured." });
    return;
  }

  const authorization = req.get("authorization") ?? "";
  const provided = authorization.match(/^Bearer\s+(.+)$/i)?.[1] ?? "";
  const expectedBuffer = Buffer.from(expected);
  const providedBuffer = Buffer.from(provided);
  if (
    providedBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(providedBuffer, expectedBuffer)
  ) {
    res.status(401).json({ error: "A valid admin upload token is required." });
    return;
  }

  next();
};

function presentOptions(question: {
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
}) {
  return {
    A: question.optionA,
    B: question.optionB,
    C: question.optionC,
    D: question.optionD,
  };
}

async function loadAttempt(attemptId: string) {
  const [attempt] = await db
    .select({
      id: pqAttemptsTable.id,
      subjectId: pqAttemptsTable.subjectId,
      startedAt: pqAttemptsTable.startedAt,
      durationSeconds: pqAttemptsTable.durationSeconds,
      submittedAt: pqAttemptsTable.submittedAt,
      examName: pqExamsTable.name,
      subjectName: pqSubjectsTable.name,
    })
    .from(pqAttemptsTable)
    .innerJoin(
      pqSubjectsTable,
      eq(pqAttemptsTable.subjectId, pqSubjectsTable.id),
    )
    .innerJoin(pqExamsTable, eq(pqSubjectsTable.examId, pqExamsTable.id))
    .where(eq(pqAttemptsTable.id, attemptId));

  return attempt;
}

async function buildAttemptResponse(attemptId: string) {
  const attempt = await loadAttempt(attemptId);
  if (!attempt) return null;

  const questions = await db
    .select({
      id: pqQuestionsTable.id,
      position: pqAttemptQuestionsTable.position,
      body: pqQuestionsTable.body,
      optionA: pqQuestionsTable.optionA,
      optionB: pqQuestionsTable.optionB,
      optionC: pqQuestionsTable.optionC,
      optionD: pqQuestionsTable.optionD,
    })
    .from(pqAttemptQuestionsTable)
    .innerJoin(
      pqQuestionsTable,
      eq(pqAttemptQuestionsTable.questionId, pqQuestionsTable.id),
    )
    .where(eq(pqAttemptQuestionsTable.attemptId, attemptId))
    .orderBy(asc(pqAttemptQuestionsTable.position));

  return StartAttemptResponse.parse({
    id: attempt.id,
    examName: attempt.examName,
    subjectName: attempt.subjectName,
    startedAt: attempt.startedAt,
    expiresAt: new Date(
      attempt.startedAt.getTime() + attempt.durationSeconds * 1000,
    ),
    questions: questions.map((question) => ({
      id: question.id,
      position: question.position,
      body: question.body,
      options: presentOptions(question),
    })),
  });
}

async function buildAttemptResult(attemptId: string) {
  const attempt = await loadAttempt(attemptId);
  if (!attempt || !attempt.submittedAt) return null;

  const rows = await db
    .select({
      questionId: pqQuestionsTable.id,
      position: pqAttemptQuestionsTable.position,
      body: pqQuestionsTable.body,
      optionA: pqQuestionsTable.optionA,
      optionB: pqQuestionsTable.optionB,
      optionC: pqQuestionsTable.optionC,
      optionD: pqQuestionsTable.optionD,
      selectedAnswer: pqAttemptQuestionsTable.selectedAnswer,
      correctAnswer: pqQuestionsTable.answer,
      explanation: pqQuestionsTable.explanation,
    })
    .from(pqAttemptQuestionsTable)
    .innerJoin(
      pqQuestionsTable,
      eq(pqAttemptQuestionsTable.questionId, pqQuestionsTable.id),
    )
    .where(eq(pqAttemptQuestionsTable.attemptId, attemptId))
    .orderBy(asc(pqAttemptQuestionsTable.position));

  const score = rows.reduce(
    (sum, row) => sum + (row.selectedAnswer === row.correctAnswer ? 1 : 0),
    0,
  );

  return SubmitAttemptResponse.parse({
    id: attempt.id,
    examName: attempt.examName,
    subjectName: attempt.subjectName,
    score,
    total: rows.length,
    percentage: rows.length ? Math.round((score / rows.length) * 100) : 0,
    submittedAt: attempt.submittedAt,
    review: rows.map((row) => ({
      questionId: row.questionId,
      position: row.position,
      body: row.body,
      options: presentOptions(row),
      selectedAnswer: row.selectedAnswer,
      correctAnswer: row.correctAnswer,
      explanation: row.explanation,
      isCorrect: row.selectedAnswer === row.correctAnswer,
    })),
  });
}

router.get("/catalog", async (_req, res): Promise<void> => {
  const [exams, subjects, questionCounts, years, latest] = await Promise.all([
    db.select().from(pqExamsTable).orderBy(asc(pqExamsTable.name)),
    db.select().from(pqSubjectsTable).orderBy(asc(pqSubjectsTable.name)),
    db
      .select({
        subjectId: pqQuestionsTable.subjectId,
        questionCount: count(),
      })
      .from(pqQuestionsTable)
      .groupBy(pqQuestionsTable.subjectId),
    db
      .selectDistinct({
        subjectId: pqQuestionsTable.subjectId,
        year: pqQuestionsTable.year,
      })
      .from(pqQuestionsTable)
      .where(isNotNull(pqQuestionsTable.year))
      .orderBy(asc(pqQuestionsTable.year)),
    db
      .select({ lastUpdatedAt: max(pqQuestionsTable.createdAt) })
      .from(pqQuestionsTable),
  ]);

  const countsBySubject = new Map(
    questionCounts.map((row) => [row.subjectId, Number(row.questionCount)]),
  );
  const yearsBySubject = new Map<number, number[]>();
  for (const row of years) {
    if (row.year == null) continue;
    const current = yearsBySubject.get(row.subjectId) ?? [];
    current.push(row.year);
    yearsBySubject.set(row.subjectId, current);
  }

  const subjectsByExam = new Map<number, typeof subjects>();
  for (const subject of subjects) {
    const current = subjectsByExam.get(subject.examId) ?? [];
    current.push(subject);
    subjectsByExam.set(subject.examId, current);
  }

  const payload = GetCatalogResponse.parse({
    exams: exams.map((exam) => ({
      id: exam.id,
      name: exam.name,
      subjects: (subjectsByExam.get(exam.id) ?? [])
        .filter((subject) => (countsBySubject.get(subject.id) ?? 0) > 0)
        .map((subject) => ({
          id: subject.id,
          name: subject.name,
          durationMin: subject.durationMin,
          questionCount: countsBySubject.get(subject.id) ?? 0,
          years: yearsBySubject.get(subject.id) ?? [],
        })),
    })),
    totalQuestions: [...countsBySubject.values()].reduce(
      (total, value) => total + value,
      0,
    ),
    totalSubjects: subjects.filter((s) => (countsBySubject.get(s.id) ?? 0) > 0).length,
    lastUpdatedAt: latest[0]?.lastUpdatedAt ?? null,
  });

  res.json(payload);
});

router.post("/attempts", async (req, res): Promise<void> => {
  const parsed = StartAttemptBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [subject] = await db
    .select({
      id: pqSubjectsTable.id,
      durationMin: pqSubjectsTable.durationMin,
      examName: pqExamsTable.name,
      subjectName: pqSubjectsTable.name,
    })
    .from(pqSubjectsTable)
    .innerJoin(pqExamsTable, eq(pqSubjectsTable.examId, pqExamsTable.id))
    .where(eq(pqSubjectsTable.id, parsed.data.subjectId));

  if (!subject) {
    res.status(404).json({ error: "Subject not found." });
    return;
  }

  const requestedCount = Math.min(parsed.data.questionCount ?? 20, 100);
  const questions = await db
    .select()
    .from(pqQuestionsTable)
    .where(eq(pqQuestionsTable.subjectId, subject.id))
    .orderBy(sql`random()`)
    .limit(requestedCount);

  if (questions.length === 0) {
    res.status(404).json({ error: "This subject has no questions yet." });
    return;
  }

  const attemptId = randomUUID();
  const startedAt = new Date();
  const durationSeconds = subject.durationMin * 60;

  await db.transaction(async (tx) => {
    await tx.insert(pqAttemptsTable).values({
      id: attemptId,
      subjectId: subject.id,
      startedAt,
      durationSeconds,
      total: questions.length,
    });
    await tx.insert(pqAttemptQuestionsTable).values(
      questions.map((question, index) => ({
        attemptId,
        questionId: question.id,
        position: index + 1,
      })),
    );
  });

  const response = await buildAttemptResponse(attemptId);
  res.status(201).json(response);
});

router.get("/attempts/:attemptId", async (req, res): Promise<void> => {
  const params = GetAttemptParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const attempt = await loadAttempt(params.data.attemptId);
  if (!attempt) {
    res.status(404).json({ error: "Attempt not found." });
    return;
  }
  if (attempt.submittedAt) {
    res.status(409).json({ error: "This attempt has already been submitted." });
    return;
  }

  const response = await buildAttemptResponse(params.data.attemptId);
  if (!response) {
    res.status(404).json({ error: "Attempt not found." });
    return;
  }
  res.json(GetAttemptResponse.parse(response));
});

router.post("/attempts/:attemptId/submit", async (req, res): Promise<void> => {
  const params = SubmitAttemptParams.safeParse(req.params);
  const parsed = SubmitAttemptBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const submittedIds = new Set<number>();
  for (const answer of parsed.data.answers) {
    if (submittedIds.has(answer.questionId)) {
      res.status(400).json({ error: "Each question can only be answered once." });
      return;
    }
    submittedIds.add(answer.questionId);
  }

  const attemptId = params.data.attemptId;
  const submission = await db.transaction(async (tx) => {
    const [attempt] = await tx
      .select()
      .from(pqAttemptsTable)
      .where(eq(pqAttemptsTable.id, attemptId))
      .for("update");

    if (!attempt) {
      return { status: 404 as const, error: "Attempt not found." };
    }
    if (attempt.submittedAt) {
      return {
        status: 409 as const,
        error: "This attempt has already been submitted.",
      };
    }

    // Reject submissions that are far past the timed window (30s grace for network lag).
    const expiresAtMs =
      attempt.startedAt.getTime() + attempt.durationSeconds * 1000 + 30_000;
    if (Date.now() > expiresAtMs) {
      return {
        status: 400 as const,
        error: "This practice session has expired. Start a new attempt.",
      };
    }

    const attemptQuestions = await tx
      .select({ questionId: pqAttemptQuestionsTable.questionId })
      .from(pqAttemptQuestionsTable)
      .where(eq(pqAttemptQuestionsTable.attemptId, attemptId));
    const allowedIds = new Set(attemptQuestions.map((row) => row.questionId));
    if (parsed.data.answers.some((answer) => !allowedIds.has(answer.questionId))) {
      return {
        status: 400 as const,
        error: "An answer refers to a question outside this attempt.",
      };
    }

    const answersByQuestion = new Map(
      parsed.data.answers.map((answer) => [answer.questionId, answer.answer]),
    );
    for (const question of attemptQuestions) {
      await tx
        .update(pqAttemptQuestionsTable)
        .set({
          selectedAnswer: answersByQuestion.get(question.questionId) ?? null,
        })
        .where(
          and(
            eq(pqAttemptQuestionsTable.attemptId, attemptId),
            eq(pqAttemptQuestionsTable.questionId, question.questionId),
          ),
        );
    }

    const gradeRows = await tx
      .select({
        correctAnswer: pqQuestionsTable.answer,
        selectedAnswer: pqAttemptQuestionsTable.selectedAnswer,
      })
      .from(pqAttemptQuestionsTable)
      .innerJoin(
        pqQuestionsTable,
        eq(pqAttemptQuestionsTable.questionId, pqQuestionsTable.id),
      )
      .where(eq(pqAttemptQuestionsTable.attemptId, attemptId));
    const score = gradeRows.reduce(
      (total, row) =>
        total + (row.correctAnswer === row.selectedAnswer ? 1 : 0),
      0,
    );

    await tx
      .update(pqAttemptsTable)
      .set({ submittedAt: new Date(), score })
      .where(eq(pqAttemptsTable.id, attemptId));
    return { status: 200 as const, error: null };
  });

  if (submission.status !== 200) {
    res.status(submission.status).json({ error: submission.error });
    return;
  }

  const result = await buildAttemptResult(attemptId);
  if (!result) {
    res.status(404).json({ error: "Attempt not found." });
    return;
  }
  res.json(result);
});

router.get("/attempts/:attemptId/result", async (req, res): Promise<void> => {
  const params = GetAttemptResultParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const attempt = await loadAttempt(params.data.attemptId);
  if (!attempt) {
    res.status(404).json({ error: "Attempt not found." });
    return;
  }
  if (!attempt.submittedAt) {
    res.status(409).json({ error: "This attempt has not been submitted." });
    return;
  }

  const result = await buildAttemptResult(params.data.attemptId);
  res.json(GetAttemptResultResponse.parse(result));
});

router.post(
  "/admin/subjects",
  requireAdminUploadToken,
  async (req, res): Promise<void> => {
    const parsed = CreateAdminSubjectBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const examName = parsed.data.examName.trim();
    const subjectName = parsed.data.subjectName.trim();
    if (!examName || !subjectName) {
      res.status(400).json({ error: "Exam and subject names cannot be blank." });
      return;
    }

    const subject = await db.transaction(async (tx) => {
      const [exam] = await tx
        .insert(pqExamsTable)
        .values({ name: examName })
        .onConflictDoUpdate({
          target: pqExamsTable.name,
          set: { name: examName },
        })
        .returning();
      const [savedSubject] = await tx
        .insert(pqSubjectsTable)
        .values({
          examId: exam.id,
          name: subjectName,
          durationMin: parsed.data.durationMin,
        })
        .onConflictDoUpdate({
          target: [pqSubjectsTable.examId, pqSubjectsTable.name],
          set: { durationMin: parsed.data.durationMin },
        })
        .returning();

      return {
        id: savedSubject.id,
        examId: exam.id,
        examName: exam.name,
        name: savedSubject.name,
        durationMin: savedSubject.durationMin,
      };
    });

    res.status(201).json(CreateAdminSubjectResponse.parse(subject));
  },
);

router.post(
  "/admin/imports/preview",
  requireAdminUploadToken,
  async (req, res): Promise<void> => {
    const parsed = PreviewQuestionImportBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const validationError = importValidationError(parsed.data);
    if (validationError) {
      res.status(400).json({ error: validationError });
      return;
    }

    const examName = parsed.data.examName.trim();
    const subjectName = parsed.data.subjectName.trim();
    const [subject] = await db
      .select({ id: pqSubjectsTable.id })
      .from(pqSubjectsTable)
      .innerJoin(
        pqExamsTable,
        eq(pqSubjectsTable.examId, pqExamsTable.id),
      )
      .where(
        and(
          eq(pqExamsTable.name, examName),
          eq(pqSubjectsTable.name, subjectName),
        ),
      );

    const normalizedBodies = [
      ...new Set(
        parsed.data.questions.map((question) =>
          normalizedQuestionText(question.body),
        ),
      ),
    ];
    const existingQuestions = subject
      ? await db
          .select({
            body: pqQuestionsTable.body,
            optionA: pqQuestionsTable.optionA,
            optionB: pqQuestionsTable.optionB,
            optionC: pqQuestionsTable.optionC,
            optionD: pqQuestionsTable.optionD,
          })
          .from(pqQuestionsTable)
          .where(
            and(
              eq(pqQuestionsTable.subjectId, subject.id),
              inArray(
                normalizedQuestionBodySql(),
                normalizedBodies,
              ),
            ),
          )
      : [];
    const duplicatePreview = classifyQuestionDuplicates(
      parsed.data.questions,
      existingQuestions,
    );

    res.json(
      PreviewQuestionImportResponse.parse({
        duplicateCount: duplicatePreview.duplicates.length,
        newQuestionCount: duplicatePreview.newQuestionCount,
        duplicates: duplicatePreview.duplicates,
      }),
    );
  },
);

router.post(
  "/admin/imports",
  requireAdminUploadToken,
  async (req, res): Promise<void> => {
    const parsed = ImportQuestionsBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const validationError = importValidationError(parsed.data);
    if (validationError) {
      res.status(400).json({ error: validationError });
      return;
    }

    const examName = parsed.data.examName.trim();
    const subjectName = parsed.data.subjectName.trim();
    const result = await db.transaction(async (tx) => {
      const [exam] = await tx
        .insert(pqExamsTable)
        .values({ name: examName })
        .onConflictDoUpdate({
          target: pqExamsTable.name,
          set: { name: examName },
        })
        .returning();
      const [subject] = await tx
        .insert(pqSubjectsTable)
        .values({
          examId: exam.id,
          name: subjectName,
          durationMin: parsed.data.durationMin ?? 30,
        })
        .onConflictDoUpdate({
          target: [pqSubjectsTable.examId, pqSubjectsTable.name],
          set: { durationMin: parsed.data.durationMin ?? 30 },
        })
        .returning();

      await tx.execute(
        sql`select pg_advisory_xact_lock(${QUESTION_IMPORT_LOCK_NAMESPACE}, ${subject.id})`,
      );

      const normalizedBodies = [
        ...new Set(
          parsed.data.questions.map((question) =>
            normalizedQuestionText(question.body),
          ),
        ),
      ];
      const existingQuestions = await tx
        .select({
          body: pqQuestionsTable.body,
          optionA: pqQuestionsTable.optionA,
          optionB: pqQuestionsTable.optionB,
          optionC: pqQuestionsTable.optionC,
          optionD: pqQuestionsTable.optionD,
        })
        .from(pqQuestionsTable)
        .where(
          and(
            eq(pqQuestionsTable.subjectId, subject.id),
            inArray(
              normalizedQuestionBodySql(),
              normalizedBodies,
            ),
          ),
        );
      const duplicatePreview = classifyQuestionDuplicates(
        parsed.data.questions,
        existingQuestions,
      );
      const duplicateRows = new Set(
        duplicatePreview.duplicates.map((duplicate) => duplicate.rowNumber),
      );
      const newQuestions = parsed.data.questions.filter(
        (_question, index) => !duplicateRows.has(index + 2),
      );
      const insertedQuestions = newQuestions.length
        ? await tx
            .insert(pqQuestionsTable)
            .values(
              newQuestions.map((question) => ({
                subjectId: subject.id,
                body: question.body.trim(),
                optionA: question.options.A.trim(),
                optionB: question.options.B.trim(),
                optionC: question.options.C.trim(),
                optionD: question.options.D.trim(),
                answer: question.answer,
                explanation: question.explanation?.trim() || null,
                year: question.year ?? null,
              })),
            )
            .onConflictDoNothing()
            .returning({ id: pqQuestionsTable.id })
        : [];

      const [summary] = await tx
        .select({ total: count() })
        .from(pqQuestionsTable)
        .where(eq(pqQuestionsTable.subjectId, subject.id));

      return {
        examId: exam.id,
        subjectId: subject.id,
        examName,
        subjectName,
        added: insertedQuestions.length,
        skippedDuplicates: parsed.data.questions.length - insertedQuestions.length,
        totalQuestions: Number(summary.total),
      };
    });

    res.status(201).json(ImportQuestionsResponse.parse(result));
  },
);

export default router;
