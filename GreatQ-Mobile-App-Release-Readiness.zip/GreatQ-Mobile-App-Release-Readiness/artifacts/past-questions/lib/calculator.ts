export function evaluateExpression(source: string): number {
  const compact = source.replace(/\s/g, "");
  const tokens = compact.match(/\d+(?:\.\d*)?|\.\d+|[()+\-*/]/g) ?? [];
  if (!compact || tokens.join("") !== compact) {
    throw new Error("Invalid expression.");
  }

  let cursor = 0;

  const parsePrimary = (): number => {
    const token = tokens[cursor];
    if (token === "+" || token === "-") {
      cursor += 1;
      const value = parsePrimary();
      return token === "-" ? -value : value;
    }
    if (token === "(") {
      cursor += 1;
      const value = parseExpression();
      if (tokens[cursor] !== ")") {
        throw new Error("Missing closing parenthesis.");
      }
      cursor += 1;
      return value;
    }
    if (!token || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token)) {
      throw new Error("Expected a number.");
    }
    cursor += 1;
    return Number(token);
  };

  const parseTerm = (): number => {
    let value = parsePrimary();
    while (tokens[cursor] === "*" || tokens[cursor] === "/") {
      const operator = tokens[cursor];
      cursor += 1;
      const right = parsePrimary();
      if (operator === "/" && right === 0) {
        throw new Error("Cannot divide by zero.");
      }
      value = operator === "*" ? value * right : value / right;
    }
    return value;
  };

  function parseExpression(): number {
    let value = parseTerm();
    while (tokens[cursor] === "+" || tokens[cursor] === "-") {
      const operator = tokens[cursor];
      cursor += 1;
      const right = parseTerm();
      value = operator === "+" ? value + right : value - right;
    }
    return value;
  }

  const value = parseExpression();
  if (cursor !== tokens.length) {
    throw new Error("Unexpected input.");
  }
  return value;
}

export function formatCalculatorResult(value: number): string {
  if (value !== 0 && (Math.abs(value) >= 1e12 || Math.abs(value) < 1e-8)) {
    return value.toPrecision(8).replace(/\.?0+e/, "e");
  }
  return Number(value.toPrecision(12)).toString();
}
