/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#20352A',
    tint: '#285640',
    background: '#F5F6EF',
    foreground: '#20352A',
    card: '#FFFFFF',
    cardForeground: '#20352A',
    primary: '#285640',
    primaryForeground: '#FFFFFF',
    secondary: '#E9EFE7',
    secondaryForeground: '#20352A',
    muted: '#EBEFE9',
    mutedForeground: '#728076',
    accent: '#D4AE4F',
    accentForeground: '#29220F',
    destructive: '#B64B3E',
    destructiveForeground: '#FFFFFF',
    border: '#DDE5DB',
    input: '#DDE5DB',
  },
  dark: {
    text: '#EDF4EC',
    tint: '#8BB69A',
    background: '#121A15',
    foreground: '#EDF4EC',
    card: '#1B2820',
    cardForeground: '#EDF4EC',
    primary: '#8BB69A',
    primaryForeground: '#102017',
    secondary: '#26352B',
    secondaryForeground: '#EDF4EC',
    muted: '#25332A',
    mutedForeground: '#A8B5AA',
    accent: '#D4AE4F',
    accentForeground: '#251D0C',
    destructive: '#E27668',
    destructiveForeground: '#28100C',
    border: '#34443A',
    input: '#34443A',
  },
  radius: 18,
};

export default colors;
