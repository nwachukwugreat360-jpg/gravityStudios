import AsyncStorage from "@react-native-async-storage/async-storage";
import type { AttemptResult } from "@workspace/api-client-react";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

const HISTORY_KEY = "campus-q:practice-history:v1";

export type HistoryItem = {
  id: string;
  examName: string;
  subjectName: string;
  score: number;
  total: number;
  percentage: number;
  completedAt: string;
  completedAtLabel: string;
};

type ProgressContextValue = {
  history: HistoryItem[];
  ready: boolean;
  recordAttempt: (result: AttemptResult) => Promise<void>;
};

const ProgressContext = createContext<ProgressContextValue | null>(null);

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(HISTORY_KEY)
      .then((value) => {
        if (!active || !value) return;
        try {
          const parsed: unknown = JSON.parse(value);
          if (Array.isArray(parsed)) setHistory(parsed as HistoryItem[]);
        } catch {
          setHistory([]);
        }
      })
      .catch(() => {
        if (active) setHistory([]);
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  // Functional update avoids race conditions when multiple sessions finish close together.
  const recordAttempt = useCallback(async (result: AttemptResult) => {
    const completedAt = result.submittedAt;
    const date = new Date(completedAt);
    const item: HistoryItem = {
      id: result.id,
      examName: result.examName,
      subjectName: result.subjectName,
      score: result.score,
      total: result.total,
      percentage: result.percentage,
      completedAt,
      completedAtLabel: date.toLocaleDateString(undefined, {
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
    };

    let nextSnapshot: HistoryItem[] = [];
    setHistory((prev) => {
      nextSnapshot = [item, ...prev.filter((entry) => entry.id !== result.id)].slice(0, 100);
      return nextSnapshot;
    });
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(nextSnapshot));
  }, []);

  const value = useMemo(
    () => ({ history, ready, recordAttempt }),
    [history, ready, recordAttempt],
  );

  return <ProgressContext.Provider value={value}>{children}</ProgressContext.Provider>;
}

export function useProgress() {
  const value = useContext(ProgressContext);
  if (!value) throw new Error("useProgress must be used inside ProgressProvider.");
  return value;
}
