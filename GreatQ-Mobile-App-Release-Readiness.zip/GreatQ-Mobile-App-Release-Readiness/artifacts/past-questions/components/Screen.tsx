import { Ionicons } from "@expo/vector-icons";
import type { SubjectCatalog } from "@workspace/api-client-react";
import React, { type ReactNode } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type RefreshControlProps,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

export function Screen({
  children,
  refreshControl,
}: {
  children: ReactNode;
  refreshControl?: React.ReactElement<RefreshControlProps>;
}) {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  return (
    <ScrollView
      style={{ backgroundColor: colors.background }}
      contentInsetAdjustmentBehavior="automatic"
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      refreshControl={refreshControl}
      contentContainerStyle={[
        styles.screen,
        {
          paddingTop:
            Platform.OS === "web" ? Math.max(67, insets.top) : insets.top + 14,
          paddingBottom:
            Platform.OS === "web" ? 118 : Math.max(112, insets.bottom + 92),
        },
      ]}
    >
      {children}
    </ScrollView>
  );
}

export function SectionHeader({
  title,
  actionLabel,
  onAction,
}: {
  title: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {actionLabel && onAction ? (
        <Pressable accessibilityRole="button" onPress={onAction} style={styles.action}>
          <Text style={[styles.actionText, { color: colors.primary }]}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function EmptyState({
  title,
  body,
  icon,
}: {
  title: string;
  body: string;
  icon: React.ComponentProps<typeof Ionicons>["name"];
}) {
  const colors = useColors();
  return (
    <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name={icon} size={24} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>{body}</Text>
    </View>
  );
}

export function SubjectCard({
  subject,
  examName,
  onPress,
  disabled = false,
}: {
  subject: SubjectCatalog;
  examName: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Start ${subject.name} practice`}
      testID={`subject-${subject.id}`}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.subjectCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && styles.pressed,
        disabled && { opacity: 0.55 },
      ]}
    >
      <View style={[styles.subjectIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name="book-outline" size={21} color={colors.primary} />
      </View>
      <View style={styles.subjectCopy}>
        <Text style={[styles.examLabel, { color: colors.mutedForeground }]} numberOfLines={1}>
          {examName}
        </Text>
        <Text style={[styles.subjectName, { color: colors.foreground }]} numberOfLines={1}>
          {subject.name}
        </Text>
        <View style={styles.metadataRow}>
          <Text style={[styles.metadata, { color: colors.mutedForeground }]}>
            {subject.questionCount} questions
          </Text>
          <View style={[styles.metaDot, { backgroundColor: colors.border }]} />
          <Text style={[styles.metadata, { color: colors.mutedForeground }]}>
            {subject.durationMin} min
          </Text>
          {subject.years.length ? (
            <>
              <View style={[styles.metaDot, { backgroundColor: colors.border }]} />
              <Text style={[styles.metadata, { color: colors.mutedForeground }]}>
                {subject.years.slice(-2).join(", ")}
              </Text>
            </>
          ) : null}
        </View>
      </View>
      <View style={[styles.startIcon, { backgroundColor: colors.primary }]}>
        <Ionicons name="arrow-forward" size={15} color={colors.primaryForeground} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { paddingHorizontal: 21, gap: 14 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 7, marginBottom: 0 },
  sectionTitle: { fontSize: 17, lineHeight: 22, fontWeight: "700", letterSpacing: -0.25 },
  action: { paddingVertical: 7, paddingLeft: 12 },
  actionText: { fontSize: 11, fontWeight: "700" },
  emptyCard: { alignItems: "center", paddingHorizontal: 22, paddingVertical: 25, borderRadius: 20, borderWidth: 1, gap: 9 },
  emptyIcon: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 3 },
  emptyTitle: { fontSize: 14, fontWeight: "700", textAlign: "center" },
  emptyBody: { fontSize: 12, lineHeight: 18, textAlign: "center", maxWidth: 300 },
  subjectCard: { borderWidth: 1, borderRadius: 18, padding: 12, flexDirection: "row", alignItems: "center", gap: 11 },
  subjectIcon: { width: 43, height: 43, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  subjectCopy: { flex: 1 },
  examLabel: { fontSize: 9, lineHeight: 13, fontWeight: "600", letterSpacing: 0.2 },
  subjectName: { fontSize: 14, lineHeight: 19, fontWeight: "700", marginTop: 1 },
  metadataRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 5, flexWrap: "wrap" },
  metadata: { fontSize: 9 },
  metaDot: { width: 3, height: 3, borderRadius: 2 },
  startIcon: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
});
