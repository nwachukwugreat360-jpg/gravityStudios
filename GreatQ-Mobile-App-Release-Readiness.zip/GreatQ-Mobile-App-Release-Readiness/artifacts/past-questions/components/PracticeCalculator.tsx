import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { evaluateExpression, formatCalculatorResult } from "@/lib/calculator";

const keyRows = [
  ["C", "(", ")", "⌫"],
  ["7", "8", "9", "÷"],
  ["4", "5", "6", "×"],
  ["1", "2", "3", "−"],
  ["0", "00", ".", "+"],
];

export function PracticeCalculatorModal({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const [expression, setExpression] = useState("");
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState("");

  const pressKey = (key: string) => {
    setError("");
    if (key === "C") {
      setExpression("");
      setAnswer("");
      return;
    }
    if (key === "⌫") {
      if (answer) {
        setExpression(answer.slice(0, -1));
        setAnswer("");
      } else {
        setExpression((current) => current.slice(0, -1));
      }
      return;
    }
    if (key === "=") {
      try {
        const value = evaluateExpression(expression || answer);
        if (!Number.isFinite(value)) throw new Error("Result is outside the calculator range.");
        setAnswer(formatCalculatorResult(value));
      } catch {
        setError("Check the expression and try again.");
      }
      return;
    }
    const token = key === "×" ? "*" : key === "÷" ? "/" : key === "−" ? "-" : key;
    const isOperator = ["+", "-", "*", "/"].includes(token);
    setExpression((current) => (
      answer ? (isOperator ? `${answer}${token}` : token) : `${current}${token}`
    ));
    setAnswer("");
  };

  const displayedExpression = (expression || "0")
    .replaceAll("*", "×")
    .replaceAll("/", "÷")
    .replaceAll("-", "−");

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <View style={[styles.backdrop, { backgroundColor: `${colors.foreground}99` }]}>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.header}>
            <View>
              <Text style={[styles.eyebrow, { color: colors.primary }]}>MATH PRACTICE</Text>
              <Text style={[styles.title, { color: colors.foreground }]}>Calculator</Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close calculator"
              onPress={onClose}
              style={styles.close}
            >
              <Feather name="x" size={20} color={colors.foreground} />
            </Pressable>
          </View>
          <View style={[styles.display, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Text numberOfLines={1} adjustsFontSizeToFit style={[styles.expression, { color: colors.mutedForeground }]}>
              {displayedExpression}
            </Text>
            <Text numberOfLines={1} adjustsFontSizeToFit style={[styles.answer, { color: error ? colors.destructive : colors.foreground }]}>
              {error || answer || " "}
            </Text>
          </View>
          <View style={styles.keypad}>
            {keyRows.map((row) => (
              <View key={row[0]} style={styles.row}>
                {row.map((key) => {
                  const isOperator = ["+", "−", "×", "÷", "(", ")"].includes(key);
                  const isClear = key === "C" || key === "⌫";
                  return (
                    <Pressable
                      key={key}
                      accessibilityRole="button"
                      accessibilityLabel={key === "⌫" ? "Delete last digit" : key === "C" ? "Clear calculator" : key}
                      onPress={() => pressKey(key)}
                      style={({ pressed }) => [
                        styles.key,
                        {
                          backgroundColor: isOperator ? colors.secondary : isClear ? colors.muted : colors.background,
                          borderColor: colors.border,
                        },
                        pressed && styles.pressed,
                      ]}
                    >
                      <Text style={[styles.keyText, { color: isOperator ? colors.primary : colors.foreground }]}>
                        {key}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            ))}
          </View>
          <Pressable
            accessibilityRole="button"
            testID="calculator-equals"
            onPress={() => pressKey("=")}
            style={({ pressed }) => [
              styles.equals,
              { backgroundColor: colors.primary },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.equalsText, { color: colors.primaryForeground }]}>Calculate</Text>
            <Text style={[styles.equalsText, { color: colors.primaryForeground }]}>＝</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  card: { width: "100%", maxWidth: 420, borderWidth: 1, borderRadius: 25, padding: 17, gap: 13 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { fontSize: 9, letterSpacing: 1.2, fontWeight: "700" },
  title: { fontSize: 20, fontWeight: "700", marginTop: 2 },
  close: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  display: { minHeight: 90, borderWidth: 1, borderRadius: 16, padding: 13, justifyContent: "space-between", alignItems: "flex-end" },
  expression: { width: "100%", textAlign: "right", fontSize: 17, fontVariant: ["tabular-nums"] },
  answer: { width: "100%", textAlign: "right", fontSize: 26, fontWeight: "700", fontVariant: ["tabular-nums"] },
  keypad: { gap: 8 },
  row: { flexDirection: "row", gap: 8 },
  key: { flex: 1, minHeight: 48, borderWidth: 1, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  keyText: { fontSize: 16, fontWeight: "600" },
  equals: { minHeight: 48, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16 },
  equalsText: { fontSize: 14, fontWeight: "700" },
  pressed: { opacity: 0.75 },
});
