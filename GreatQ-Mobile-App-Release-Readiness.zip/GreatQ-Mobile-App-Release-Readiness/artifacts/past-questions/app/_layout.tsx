import React, { useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ActivityIndicator, Platform, StyleSheet, Text, View, useColorScheme } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import colors from '@/constants/colors';
import { ProgressProvider } from '@/state/ProgressContext';
import { setBaseUrl } from '@workspace/api-client-react';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();
const apiDomain = process.env.EXPO_PUBLIC_DOMAIN;
// On native, EXPO_PUBLIC_DOMAIN is required. Prefer a clear runtime message over a hard crash
// so misconfigured builds still surface something actionable in logs / ErrorBoundary.
if (Platform.OS !== 'web' && !apiDomain) {
  console.error(
    'EXPO_PUBLIC_DOMAIN must be set so the app can reach its API. ' +
      'Set it in your Expo env / Replit secrets before building.',
  );
}
setBaseUrl(
  Platform.OS === 'web'
    ? window.location.origin
    : apiDomain
      ? `https://${apiDomain}`
      : 'http://localhost',
);

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerBackTitle: 'Back' }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="quiz/[attemptId]" options={{ headerShown: false }} />
      <Stack.Screen name="result/[attemptId]" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });
  const [fontLoadTimedOut, setFontLoadTimedOut] = useState(false);
  const colorScheme = useColorScheme();
  const startupColors = colorScheme === 'dark' ? colors.dark : colors.light;

  useEffect(() => {
    if (fontsLoaded || fontError || fontLoadTimedOut) {
      void SplashScreen.hideAsync().catch(() => {});
      return;
    }

    const fallbackTimer = setTimeout(() => {
      setFontLoadTimedOut(true);
      void SplashScreen.hideAsync().catch(() => {});
    }, 3_000);
    return () => clearTimeout(fallbackTimer);
  }, [fontLoadTimedOut, fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError && !fontLoadTimedOut) {
    return (
      <View style={[styles.startup, { backgroundColor: startupColors.background }]}>
        <ActivityIndicator color={startupColors.primary} size="large" />
        <Text style={[styles.startupLabel, { color: startupColors.foreground }]}>
          Opening GreatQ
        </Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView>
            <KeyboardProvider>
              <ProgressProvider>
                <RootLayoutNav />
              </ProgressProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  startup: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  startupLabel: {
    fontSize: 14,
    fontWeight: '600',
  },
});
