import { useRouter } from "expo-router";
import { Feather, Ionicons } from "@expo/vector-icons";
import { useGetCatalog, useStartAttempt } from "@workspace/api-client-react";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { EmptyState, Screen, SectionHeader, SubjectCard } from "@/components/Screen";
import { useColors } from "@/hooks/useColors";
import { useProgress } from "@/state/ProgressContext";
import type { SubjectCatalog } from "@workspace/api-client-react";

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const catalog = useGetCatalog({ query: { refetchInterval: 60_000 } });
  const startAttempt = useStartAttempt();
  const { history } = useProgress();
  const featured = catalog.data?.exams.flatMap((exam) =>
    exam.subjects.map((subject) => ({ ...subject, examName: exam.name })),
  ).slice(0, 4) ?? [];

  const beginPractice = async (subject: SubjectCatalog) => {
    try {
      const attempt = await startAttempt.mutateAsync({
        data: { subjectId: subject.id },
      });
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      router.push({
        pathname: "/quiz/[attemptId]",
        params: { attemptId: attempt.id },
      });
    } catch {
      // The generated mutation error is reflected in the inline message below.
    }
  };

  return (
    <Screen
      refreshControl={
        <RefreshControl
          refreshing={catalog.isRefetching}
          onRefresh={() => void catalog.refetch()}
          tintColor={colors.primary}
        />
      }
    >
      <View style={styles.brandRow}>
        <View style={styles.brand}>
          <Image source={require("../../assets/images/icon.png")} style={styles.logo} />
          <View>
            <Text style={[styles.brandName, { color: colors.foreground }]}>GreatQ</Text>
            <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>PAST QUESTIONS</Text>
          </View>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Search question bank"
          testID="home-search"
          onPress={() => router.push("/(tabs)/library")}
          style={({ pressed }) => [
            styles.iconButton,
            { backgroundColor: colors.card, borderColor: colors.border },
            pressed && styles.pressed,
          ]}
        >
          <Feather name="search" size={19} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <View style={styles.heroCopy}>
          <Text style={[styles.heroEyebrow, { color: colors.accent }]}>YOUR NEXT EXAM, WELL PREPARED</Text>
          <Text style={[styles.heroTitle, { color: colors.primaryForeground }]}>Practice past questions. Build confidence.</Text>
          <Text style={[styles.heroBody, { color: colors.primaryForeground, opacity: 0.78 }]}>
            Find your course, start a timed session, and learn from every answer.
          </Text>
          <Pressable
            accessibilityRole="button"
            testID="browse-question-bank"
            onPress={() => router.push("/(tabs)/library")}
            style={({ pressed }) => [
              styles.heroButton,
              { backgroundColor: colors.primaryForeground },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.heroButtonText, { color: colors.primary }]}>Browse question bank</Text>
            <Feather name="arrow-up-right" size={16} color={colors.primary} />
          </Pressable>
        </View>
        <View style={styles.heroMark} pointerEvents="none">
          <Ionicons
            name="book-outline"
            size={92}
            color={colors.primaryForeground}
            style={{ opacity: 0.14 }}
          />
          <View style={[styles.heroMarkDot, { backgroundColor: colors.accent }]} />
        </View>
      </View>

      {catalog.data ? (
        <View style={styles.statsRow}>
          <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
              <Ionicons name="documents-outline" size={18} color={colors.primary} />
            </View>
            <Text style={[styles.statValue, { color: colors.foreground }]}>
              {catalog.data.totalQuestions.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>questions</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
              <Ionicons name="library-outline" size={18} color={colors.primary} />
            </View>
            <Text style={[styles.statValue, { color: colors.foreground }]}>
              {catalog.data.totalSubjects.toLocaleString()}
            </Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>subjects</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
              <Ionicons name="sync-outline" size={18} color={colors.primary} />
            </View>
            <Text style={[styles.statValue, { color: colors.foreground }]}>Live</Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>updated by admin</Text>
          </View>
        </View>
      ) : null}

      <SectionHeader
        title="Pick up where you left off"
        actionLabel={history.length ? "See progress" : undefined}
        onAction={() => router.push("/(tabs)/progress")}
      />
      {history.length ? (
        <Pressable
          accessibilityRole="button"
          testID="recent-attempt"
          onPress={() =>
            router.push({
              pathname: "/result/[attemptId]",
              params: { attemptId: history[0].id },
            })
          }
          style={({ pressed }) => [
            styles.recentCard,
            { backgroundColor: colors.card, borderColor: colors.border },
            pressed && styles.pressed,
          ]}
        >
          <View style={[styles.recentIcon, { backgroundColor: colors.secondary }]}>
            <Ionicons name="time-outline" size={20} color={colors.primary} />
          </View>
          <View style={styles.recentInfo}>
            <Text style={[styles.recentTitle, { color: colors.foreground }]} numberOfLines={1}>
              {history[0].subjectName}
            </Text>
            <Text style={[styles.recentSubtitle, { color: colors.mutedForeground }]} numberOfLines={1}>
              {history[0].examName} · {history[0].completedAtLabel}
            </Text>
          </View>
          <View style={[styles.scorePill, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.scorePillText, { color: colors.primary }]}>
              {history[0].percentage}%
            </Text>
          </View>
        </Pressable>
      ) : (
        <View style={[styles.firstSession, { backgroundColor: colors.secondary }]}>
          <Ionicons name="sparkles-outline" size={19} color={colors.primary} />
          <Text style={[styles.firstSessionText, { color: colors.foreground }]}>
            Your completed practice sessions will appear here.
          </Text>
        </View>
      )}

      <SectionHeader
        title="Popular subjects"
        actionLabel="View all"
        onAction={() => router.push("/(tabs)/library")}
      />
      {catalog.isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Loading question bank</Text>
        </View>
      ) : catalog.isError ? (
        <View style={[styles.errorBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.errorText, { color: colors.foreground }]}>
            The question bank could not be reached.
          </Text>
          <Pressable onPress={() => void catalog.refetch()}>
            <Text style={[styles.retryText, { color: colors.primary }]}>Try again</Text>
          </Pressable>
        </View>
      ) : featured.length ? (
        <View style={styles.subjectList}>
          {featured.map((subject) => (
            <SubjectCard
              key={subject.id}
              subject={subject}
              examName={subject.examName}
              onPress={() => void beginPractice(subject)}
              disabled={startAttempt.isPending}
            />
          ))}
        </View>
      ) : (
        <EmptyState
          title="The library is waiting for its first upload"
          body="New question sets added by the admin will appear here automatically."
          icon="cloud-upload-outline"
        />
      )}
      {startAttempt.isError ? (
        <Text style={[styles.mutationError, { color: colors.destructive }]}>
          Could not start practice. Please try again.
        </Text>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  brandRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 22 },
  brand: { flexDirection: "row", alignItems: "center", gap: 11 },
  logo: { width: 42, height: 42, borderRadius: 13 },
  brandName: { fontSize: 18, fontWeight: "700", letterSpacing: -0.4 },
  brandCaption: { fontSize: 9, fontWeight: "700", letterSpacing: 1.7, marginTop: 2 },
  iconButton: { width: 42, height: 42, borderWidth: 1, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  hero: { minHeight: 250, borderRadius: 26, padding: 23, overflow: "hidden", justifyContent: "center" },
  heroCopy: { maxWidth: 280, zIndex: 1 },
  heroEyebrow: { fontSize: 10, fontWeight: "700", letterSpacing: 1.4, marginBottom: 12 },
  heroTitle: { fontSize: 28, lineHeight: 34, fontWeight: "700", letterSpacing: -0.7 },
  heroBody: { fontSize: 13, lineHeight: 19, marginTop: 10 },
  heroButton: { marginTop: 19, alignSelf: "flex-start", paddingHorizontal: 14, paddingVertical: 11, borderRadius: 13, flexDirection: "row", alignItems: "center", gap: 8 },
  heroButtonText: { fontSize: 12, fontWeight: "700" },
  heroMark: { position: "absolute", right: -4, bottom: -9, transform: [{ rotate: "-13deg" }] },
  heroMarkDot: { width: 18, height: 18, borderRadius: 9, position: "absolute", top: 7, right: 22 },
  statsRow: { flexDirection: "row", gap: 9, marginTop: 15 },
  statCard: { flex: 1, minHeight: 101, borderWidth: 1, borderRadius: 18, padding: 12 },
  statIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 9 },
  statValue: { fontSize: 17, fontWeight: "700" },
  statLabel: { fontSize: 10, marginTop: 2 },
  recentCard: { borderWidth: 1, borderRadius: 18, padding: 13, flexDirection: "row", alignItems: "center", gap: 11 },
  recentIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  recentInfo: { flex: 1 },
  recentTitle: { fontSize: 13, fontWeight: "700" },
  recentSubtitle: { fontSize: 10, marginTop: 4 },
  scorePill: { borderRadius: 11, paddingHorizontal: 10, paddingVertical: 7 },
  scorePillText: { fontSize: 12, fontWeight: "700" },
  firstSession: { padding: 14, borderRadius: 16, flexDirection: "row", alignItems: "center", gap: 10 },
  firstSessionText: { fontSize: 12, lineHeight: 18, flex: 1 },
  subjectList: { gap: 10 },
  loading: { padding: 26, alignItems: "center", gap: 10 },
  loadingText: { fontSize: 12 },
  errorBox: { padding: 16, borderRadius: 16, borderWidth: 1, gap: 10 },
  errorText: { fontSize: 13 },
  retryText: { fontSize: 13, fontWeight: "700" },
  mutationError: { fontSize: 12, marginTop: 10 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
});
