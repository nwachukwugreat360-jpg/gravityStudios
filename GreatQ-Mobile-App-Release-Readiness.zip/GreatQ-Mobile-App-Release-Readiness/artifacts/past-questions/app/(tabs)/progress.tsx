import { Feather, Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { EmptyState, Screen, SectionHeader } from "@/components/Screen";
import { useColors } from "@/hooks/useColors";
import { useProgress } from "@/state/ProgressContext";

export default function ProgressScreen() {
  const colors = useColors();
  const router = useRouter();
  const { history, ready } = useProgress();
  const average = history.length
    ? Math.round(history.reduce((sum, item) => sum + item.percentage, 0) / history.length)
    : 0;
  const best = history.length ? Math.max(...history.map((item) => item.percentage)) : 0;

  return (
    <Screen>
      <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR STUDY RECORD</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>Progress</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Your practice history is saved on this device.
      </Text>

      <View style={styles.stats}>
        <View style={[styles.statCard, { backgroundColor: colors.primary }]}>
          <Ionicons name="checkmark-circle-outline" size={20} color={colors.primaryForeground} />
          <Text style={[styles.statValue, { color: colors.primaryForeground }]}>{history.length}</Text>
          <Text style={[styles.statLabel, { color: colors.primaryForeground, opacity: 0.78 }]}>sessions</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="analytics-outline" size={20} color={colors.primary} />
          <Text style={[styles.statValue, { color: colors.foreground }]}>{average}%</Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>average score</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="trophy-outline" size={20} color={colors.accent} />
          <Text style={[styles.statValue, { color: colors.foreground }]}>{best}%</Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>personal best</Text>
        </View>
      </View>

      <SectionHeader title="Recent sessions" />
      {!ready ? (
        <Text style={[styles.note, { color: colors.mutedForeground }]}>Loading your local history…</Text>
      ) : history.length ? (
        <View style={styles.historyList}>
          {history.map((item) => (
            <ResultRow key={item.id} item={item} onPress={() =>
              router.push({ pathname: "/result/[attemptId]", params: { attemptId: item.id } })
            } />
          ))}
        </View>
      ) : (
        <EmptyState
          title="A fresh start"
          body="Complete a practice session and your scores will be saved here."
          icon="bar-chart-outline"
        />
      )}
    </Screen>
  );
}

function ResultRow({
  item,
  onPress,
}: {
  item: ReturnType<typeof useProgress>["history"][number];
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      testID={`history-${item.id}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.historyRow,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && { opacity: 0.78 },
      ]}
    >
      <View style={[styles.historyIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name="document-text-outline" size={20} color={colors.primary} />
      </View>
      <View style={styles.historyBody}>
        <Text style={[styles.historyTitle, { color: colors.foreground }]} numberOfLines={1}>{item.subjectName}</Text>
        <Text style={[styles.historyCaption, { color: colors.mutedForeground }]} numberOfLines={1}>
          {item.examName} · {item.completedAtLabel} · {item.score}/{item.total}
        </Text>
      </View>
      <View style={styles.historyScore}>
        <Text style={[styles.historyPercent, { color: colors.primary }]}>{item.percentage}%</Text>
        <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  eyebrow: { fontSize: 10, fontWeight: "700", letterSpacing: 1.5, marginBottom: 7 },
  title: { fontSize: 29, lineHeight: 35, fontWeight: "700", letterSpacing: -0.7 },
  subtitle: { fontSize: 13, lineHeight: 19, marginTop: 7, marginBottom: 20 },
  stats: { flexDirection: "row", gap: 9 },
  statCard: { flex: 1, minHeight: 117, borderRadius: 18, borderWidth: 1, padding: 13, justifyContent: "center" },
  statValue: { fontSize: 23, fontWeight: "700", marginTop: 8 },
  statLabel: { fontSize: 10, marginTop: 2 },
  historyList: { gap: 9 },
  historyRow: { borderWidth: 1, borderRadius: 17, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  historyIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  historyBody: { flex: 1 },
  historyTitle: { fontSize: 13, fontWeight: "700" },
  historyCaption: { fontSize: 10, marginTop: 4 },
  historyScore: { alignItems: "center", flexDirection: "row", gap: 2 },
  historyPercent: { fontSize: 12, fontWeight: "700" },
  note: { fontSize: 12 },
});
