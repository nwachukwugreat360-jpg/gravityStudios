import { Feather, Ionicons } from "@expo/vector-icons";
import { useGetCatalog, useStartAttempt } from "@workspace/api-client-react";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { EmptyState, Screen, SectionHeader, SubjectCard } from "@/components/Screen";
import { useColors } from "@/hooks/useColors";

export default function LibraryScreen() {
  const colors = useColors();
  const router = useRouter();
  const catalog = useGetCatalog({
    query: {
      refetchInterval: 45_000,
      refetchOnMount: "always",
      refetchOnReconnect: true,
      retry: 2,
    },
  });
  const startAttempt = useStartAttempt();
  const [search, setSearch] = useState("");
  const [activeExam, setActiveExam] = useState<string | null>(null);
  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return (catalog.data?.exams ?? [])
      .filter((exam) => !activeExam || exam.name === activeExam)
      .flatMap((exam) =>
        exam.subjects
          .filter((subject) => {
            const yearText = subject.years.join(" ");
            return (
              !query ||
              `${exam.name} ${subject.name} ${yearText}`.toLowerCase().includes(query)
            );
          })
          .map((subject) => ({ ...subject, examName: exam.name })),
      );
  }, [activeExam, catalog.data?.exams, search]);

  const beginPractice = async (subjectId: number) => {
    try {
      const attempt = await startAttempt.mutateAsync({ data: { subjectId } });
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      router.push({ pathname: "/quiz/[attemptId]", params: { attemptId: attempt.id } });
    } catch {
      // Keep the screen in place; the inline mutation error gives retry guidance.
    }
  };

  return (
    <Screen
      refreshControl={
        <RefreshControl
          refreshing={catalog.isRefetching}
          onRefresh={() => void catalog.refetch()}
          tintColor={colors.primary}
        />
      }
    >
      <Text style={[styles.eyebrow, { color: colors.primary }]}>QUESTION BANK</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>Find your subject</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Search by course, exam, or year. New uploads appear automatically.
      </Text>
      {catalog.data ? (
        <Text style={[styles.catalogSummary, { color: colors.mutedForeground }]}>
          {catalog.data.totalQuestions.toLocaleString()} questions across{" "}
          {catalog.data.totalSubjects.toLocaleString()} subjects
        </Text>
      ) : null}

      <View style={[styles.searchBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={18} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search courses or years"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          returnKeyType="search"
          testID="library-search"
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {search ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear search"
            onPress={() => setSearch("")}
            style={styles.clearButton}
          >
            <Feather name="x" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>

      {catalog.data?.exams.length ? (
        <View style={styles.filterRow}>
          <Pressable
            onPress={() => setActiveExam(null)}
            style={[
              styles.filterChip,
              {
                backgroundColor: activeExam === null ? colors.primary : colors.card,
                borderColor: activeExam === null ? colors.primary : colors.border,
              },
            ]}
          >
            <Text style={[styles.filterText, { color: activeExam === null ? colors.primaryForeground : colors.foreground }]}>
              All exams
            </Text>
          </Pressable>
          {catalog.data.exams.map((exam) => (
            <Pressable
              key={exam.id}
              onPress={() => setActiveExam(exam.name)}
              style={[
                styles.filterChip,
                {
                  backgroundColor: activeExam === exam.name ? colors.primary : colors.card,
                  borderColor: activeExam === exam.name ? colors.primary : colors.border,
                },
              ]}
            >
              <Text
                numberOfLines={1}
                style={[
                  styles.filterText,
                  { color: activeExam === exam.name ? colors.primaryForeground : colors.foreground },
                ]}
              >
                {exam.name}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : null}

      <SectionHeader
        title={search || activeExam ? `${filtered.length} matching subjects` : "Available subjects"}
        actionLabel={catalog.data?.lastUpdatedAt ? "Updated live" : undefined}
        onAction={() => void catalog.refetch()}
      />

      {catalog.isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Loading the library</Text>
        </View>
      ) : catalog.isError ? (
        <View style={[styles.errorBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="cloud-offline-outline" size={22} color={colors.destructive} />
          <Text style={[styles.errorText, { color: colors.foreground }]}>Could not load the question bank.</Text>
          <Text style={[styles.errorDetail, { color: colors.mutedForeground }]}>
            {catalog.error instanceof Error
              ? catalog.error.message
              : "Check your connection and try again."}
          </Text>
          <Pressable onPress={() => void catalog.refetch()} style={[styles.retry, { backgroundColor: colors.primary }]}>
            <Text style={{ color: colors.primaryForeground, fontWeight: "700", fontSize: 12 }}>Try again</Text>
          </Pressable>
        </View>
      ) : filtered.length ? (
        <View style={styles.subjectList}>
          {filtered.map((subject) => (
            <SubjectCard
              key={subject.id}
              subject={subject}
              examName={subject.examName}
              onPress={() => void beginPractice(subject.id)}
              disabled={startAttempt.isPending || subject.questionCount === 0}
            />
          ))}
        </View>
      ) : (
        <EmptyState
          title={search ? "No matches found" : "No question sets yet"}
          body={
            search
              ? "Try another course name, exam, or year."
              : "Question sets uploaded by the admin will be listed here."
          }
          icon={search ? "search-outline" : "library-outline"}
        />
      )}
      {startAttempt.isError ? (
        <Text style={[styles.mutationError, { color: colors.destructive }]}>
          Could not start this practice session. Try again.
        </Text>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  eyebrow: { fontSize: 10, fontWeight: "700", letterSpacing: 1.5, marginBottom: 7 },
  title: { fontSize: 29, lineHeight: 35, fontWeight: "700", letterSpacing: -0.7 },
  subtitle: { fontSize: 13, lineHeight: 19, marginTop: 7, marginBottom: 18, maxWidth: 330 },
  catalogSummary: { fontSize: 11, fontWeight: "600", marginTop: -12, marginBottom: 2 },
  searchBar: { minHeight: 50, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 10 },
  searchInput: { flex: 1, height: 48, fontSize: 13 },
  clearButton: { padding: 7 },
  filterRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14, marginBottom: 1 },
  filterChip: { borderWidth: 1, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 20, maxWidth: "100%" },
  filterText: { fontSize: 11, fontWeight: "600" },
  subjectList: { gap: 10 },
  loading: { padding: 30, alignItems: "center", gap: 10 },
  loadingText: { fontSize: 12 },
  errorBox: { borderWidth: 1, borderRadius: 18, padding: 20, alignItems: "center", gap: 12 },
  errorText: { fontSize: 13 },
  errorDetail: { fontSize: 11, lineHeight: 17, textAlign: "center" },
  retry: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  mutationError: { fontSize: 12, marginTop: 12 },
});
