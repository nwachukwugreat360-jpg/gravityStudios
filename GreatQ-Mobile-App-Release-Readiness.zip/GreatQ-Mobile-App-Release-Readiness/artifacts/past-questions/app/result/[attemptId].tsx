import { Feather, Ionicons } from "@expo/vector-icons";
import { useGetAttemptResult } from "@workspace/api-client-react";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Screen, SectionHeader } from "@/components/Screen";
import { useColors } from "@/hooks/useColors";
import { useProgress } from "@/state/ProgressContext";

export default function ResultScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ attemptId: string }>();
  const attemptId = Array.isArray(params.attemptId) ? params.attemptId[0] : params.attemptId ?? "";
  const result = useGetAttemptResult(attemptId, {
    query: { enabled: Boolean(attemptId), retry: false },
  });
  const { recordAttempt } = useProgress();
  const recordedRef = useRef(false);

  useEffect(() => {
    if (result.data && !recordedRef.current) {
      recordedRef.current = true;
      void recordAttempt(result.data).catch(() => {});
    }
  }, [recordAttempt, result.data]);

  const goToLibrary = () => {
    void Haptics.selectionAsync();
    router.replace("/(tabs)/library");
  };

  if (result.isLoading) {
    return (
      <Screen>
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Loading your result</Text>
        </View>
      </Screen>
    );
  }

  if (!result.data) {
    return (
      <Screen>
        <View style={[styles.errorCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="document-text-outline" size={28} color={colors.mutedForeground} />
          <Text style={[styles.errorTitle, { color: colors.foreground }]}>Result unavailable</Text>
          <Text style={[styles.errorBody, { color: colors.mutedForeground }]}>
            This attempt may not have been submitted yet.
          </Text>
          <Pressable onPress={goToLibrary} style={[styles.primaryButton, { backgroundColor: colors.primary }]}>
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Back to question bank</Text>
          </Pressable>
        </View>
      </Screen>
    );
  }

  const scoreTone =
    result.data.percentage >= 70
      ? colors.primary
      : result.data.percentage >= 50
        ? colors.accent
        : colors.destructive;

  return (
    <Screen>
      <View style={styles.resultHeader}>
        <View style={[styles.resultMark, { backgroundColor: colors.secondary }]}>
          <Ionicons name="checkmark-done-outline" size={26} color={colors.primary} />
        </View>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>PRACTICE COMPLETE</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>{result.data.subjectName}</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{result.data.examName}</Text>
      </View>

      <View style={[styles.scoreCard, { backgroundColor: colors.primary }]}>
        <Text style={[styles.scoreLabel, { color: colors.primaryForeground, opacity: 0.76 }]}>YOUR SCORE</Text>
        <View style={styles.scoreRow}>
          <Text style={[styles.scoreNumber, { color: colors.primaryForeground }]}>{result.data.percentage}</Text>
          <Text style={[styles.scorePercent, { color: colors.primaryForeground }]}>%</Text>
        </View>
        <View style={styles.scoreFoot}>
          <Text style={[styles.scoreFootText, { color: colors.primaryForeground }]}>
            {result.data.score} correct of {result.data.total}
          </Text>
          <View style={[styles.scoreBadge, { backgroundColor: colors.primaryForeground }]}>
            <Text style={[styles.scoreBadgeText, { color: scoreTone }]}>
              {result.data.percentage >= 70 ? "Strong work" : result.data.percentage >= 50 ? "Keep building" : "Keep practicing"}
            </Text>
          </View>
        </View>
      </View>

      <View style={[styles.resultSummary, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.summaryItem}>
          <Ionicons name="checkmark-circle-outline" size={18} color={colors.primary} />
          <Text style={[styles.summaryNumber, { color: colors.foreground }]}>{result.data.score}</Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>correct</Text>
        </View>
        <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
        <View style={styles.summaryItem}>
          <Ionicons name="close-circle-outline" size={18} color={colors.destructive} />
          <Text style={[styles.summaryNumber, { color: colors.foreground }]}>{result.data.total - result.data.score}</Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>to review</Text>
        </View>
        <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
        <View style={styles.summaryItem}>
          <Ionicons name="calendar-outline" size={18} color={colors.accent} />
          <Text style={[styles.summaryNumber, { color: colors.foreground }]}>
            {new Date(result.data.submittedAt).toLocaleDateString(undefined, { day: "numeric", month: "short" })}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>completed</Text>
        </View>
      </View>

      <SectionHeader title="Review answers" />
      <View style={styles.reviewList}>
        {result.data.review.map((item) => (
          <View
            key={item.questionId}
            style={[
              styles.reviewCard,
              {
                backgroundColor: colors.card,
                borderColor: item.isCorrect ? colors.border : colors.destructive,
              },
            ]}
          >
            <View style={styles.reviewTop}>
              <Text style={[styles.reviewNumber, { color: colors.mutedForeground }]}>
                QUESTION {item.position}
              </Text>
              <View
                style={[
                  styles.reviewStatus,
                  { backgroundColor: item.isCorrect ? colors.secondary : colors.destructive },
                ]}
              >
                <Ionicons
                  name={item.isCorrect ? "checkmark" : "close"}
                  size={12}
                  color={item.isCorrect ? colors.primary : colors.destructiveForeground}
                />
                <Text
                  style={[
                    styles.reviewStatusText,
                    { color: item.isCorrect ? colors.primary : colors.destructiveForeground },
                  ]}
                >
                  {item.isCorrect ? "Correct" : item.selectedAnswer ? "Review" : "Skipped"}
                </Text>
              </View>
            </View>
            <Text style={[styles.reviewQuestion, { color: colors.foreground }]}>{item.body}</Text>
            <View style={styles.answerReview}>
              {item.selectedAnswer ? (
                <Text style={[styles.answerReviewLine, { color: item.isCorrect ? colors.primary : colors.destructive }]}>
                  Your answer: {item.selectedAnswer}. {item.options[item.selectedAnswer]}
                </Text>
              ) : (
                <Text style={[styles.answerReviewLine, { color: colors.mutedForeground }]}>You skipped this question.</Text>
              )}
              <Text style={[styles.answerReviewLine, { color: colors.primary }]}>
                Correct answer: {item.correctAnswer}. {item.options[item.correctAnswer]}
              </Text>
              {item.explanation ? (
                <View style={[styles.explanation, { backgroundColor: colors.secondary }]}>
                  <Text style={[styles.explanationLabel, { color: colors.primary }]}>WHY</Text>
                  <Text style={[styles.explanationText, { color: colors.foreground }]}>{item.explanation}</Text>
                </View>
              ) : null}
            </View>
          </View>
        ))}
      </View>

      <Pressable
        accessibilityRole="button"
        testID="back-to-library"
        onPress={goToLibrary}
        style={({ pressed }) => [
          styles.primaryButton,
          { backgroundColor: colors.primary },
          pressed && { opacity: 0.82 },
        ]}
      >
        <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Practice another subject</Text>
        <Feather name="arrow-right" size={17} color={colors.primaryForeground} />
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loading: { minHeight: 360, alignItems: "center", justifyContent: "center", gap: 13 },
  loadingText: { fontSize: 13 },
  errorCard: { minHeight: 300, alignItems: "center", justifyContent: "center", padding: 24, borderRadius: 22, borderWidth: 1, gap: 12 },
  errorTitle: { fontSize: 18, fontWeight: "700" },
  errorBody: { fontSize: 13, lineHeight: 19, textAlign: "center" },
  primaryButton: { minHeight: 50, paddingHorizontal: 17, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  primaryButtonText: { fontSize: 13, fontWeight: "700" },
  resultHeader: { alignItems: "center", paddingTop: 4, gap: 4 },
  resultMark: { width: 54, height: 54, borderRadius: 18, alignItems: "center", justifyContent: "center", marginBottom: 6 },
  eyebrow: { fontSize: 9, fontWeight: "700", letterSpacing: 1.5 },
  title: { fontSize: 25, lineHeight: 31, fontWeight: "700", textAlign: "center" },
  subtitle: { fontSize: 12 },
  scoreCard: { borderRadius: 23, padding: 21, minHeight: 169, justifyContent: "center" },
  scoreLabel: { fontSize: 10, fontWeight: "700", letterSpacing: 1.4 },
  scoreRow: { flexDirection: "row", alignItems: "flex-end", marginTop: 1 },
  scoreNumber: { fontSize: 60, lineHeight: 68, fontWeight: "700", letterSpacing: -2 },
  scorePercent: { fontSize: 24, fontWeight: "600", paddingBottom: 10, paddingLeft: 2 },
  scoreFoot: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 6, gap: 8 },
  scoreFootText: { fontSize: 12, fontWeight: "600" },
  scoreBadge: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 11 },
  scoreBadgeText: { fontSize: 10, fontWeight: "700" },
  resultSummary: { borderWidth: 1, borderRadius: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-around", paddingVertical: 14 },
  summaryItem: { flex: 1, alignItems: "center", gap: 3 },
  summaryNumber: { fontSize: 14, fontWeight: "700" },
  summaryLabel: { fontSize: 9 },
  summaryDivider: { width: 1, height: 39 },
  reviewList: { gap: 10 },
  reviewCard: { borderWidth: 1, borderRadius: 18, padding: 15, gap: 11 },
  reviewTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  reviewNumber: { fontSize: 9, fontWeight: "700", letterSpacing: 1.1 },
  reviewStatus: { paddingVertical: 5, paddingHorizontal: 8, borderRadius: 9, flexDirection: "row", alignItems: "center", gap: 4 },
  reviewStatusText: { fontSize: 9, fontWeight: "700" },
  reviewQuestion: { fontSize: 14, lineHeight: 21, fontWeight: "600" },
  answerReview: { gap: 7 },
  answerReviewLine: { fontSize: 11, lineHeight: 16 },
  explanation: { padding: 11, borderRadius: 12, gap: 4, marginTop: 3 },
  explanationLabel: { fontSize: 8, fontWeight: "700", letterSpacing: 1.2 },
  explanationText: { fontSize: 11, lineHeight: 17 },
});
