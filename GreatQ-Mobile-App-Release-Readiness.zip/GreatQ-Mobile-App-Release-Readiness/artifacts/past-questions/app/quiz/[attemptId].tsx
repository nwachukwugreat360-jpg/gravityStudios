import { Feather, Ionicons } from "@expo/vector-icons";
import type { AnswerChoice } from "@workspace/api-client-react";
import { useGetAttempt, useSubmitAttempt } from "@workspace/api-client-react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Screen } from "@/components/Screen";
import { PracticeCalculatorModal } from "@/components/PracticeCalculator";
import { useColors } from "@/hooks/useColors";

const choiceLetters: AnswerChoice[] = ["A", "B", "C", "D"];

export default function QuizScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ attemptId: string }>();
  const attemptId = Array.isArray(params.attemptId) ? params.attemptId[0] : params.attemptId ?? "";
  const attemptQuery = useGetAttempt(attemptId, {
    query: { enabled: Boolean(attemptId), retry: false, staleTime: 10_000 },
  });
  const submitAttempt = useSubmitAttempt();
  const attempt = attemptQuery.data;
  const [answers, setAnswers] = useState<Record<number, AnswerChoice | null>>({});
  const [answersReady, setAnswersReady] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const [submitError, setSubmitError] = useState("");
  const [showFinishConfirmation, setShowFinishConfirmation] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const submittedRef = useRef(false);
  const automaticSubmitTriedRef = useRef(false);

  useEffect(() => {
    let active = true;
    const loadAnswers = async () => {
      if (!attemptId) {
        if (active) setAnswersReady(true);
        return;
      }
      try {
        const saved = await AsyncStorage.getItem(`campus-q:attempt:${attemptId}`);
        if (active && saved) {
          const parsed: unknown = JSON.parse(saved);
          if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
            setAnswers(parsed as Record<number, AnswerChoice | null>);
          }
        }
      } catch {
        if (active) setSubmitError("Saved answers could not be restored.");
      } finally {
        if (active) setAnswersReady(true);
      }
    };
    void loadAnswers();
    return () => {
      active = false;
    };
  }, [attemptId]);

  useEffect(() => {
    if (!attempt || !attemptId || !answersReady) return;
    void AsyncStorage.setItem(
      `campus-q:attempt:${attemptId}`,
      JSON.stringify(answers),
    ).catch(() => setSubmitError("Answers could not be saved on this device."));
  }, [answers, answersReady, attempt, attemptId]);

  useEffect(() => {
    if (!attempt) return;
    const expiresAt = new Date(attempt.expiresAt).getTime();
    const updateRemaining = () => {
      setRemaining(Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000)));
    };
    updateRemaining();
    const timer = setInterval(updateRemaining, 1000);
    return () => clearInterval(timer);
  }, [attempt?.expiresAt]);

  const submitNow = useCallback(async () => {
    if (!attempt || submittedRef.current || submitAttempt.isPending) return;
    submittedRef.current = true;
    setSubmitError("");
    try {
      await submitAttempt.mutateAsync({
        attemptId,
        data: {
          answers: attempt.questions.map((question) => ({
            questionId: question.id,
            answer: answers[question.id] ?? null,
          })),
        },
      });
      // History is recorded on the Result screen after the server confirms the score.
      void AsyncStorage.removeItem(`campus-q:attempt:${attemptId}`).catch(() => {});
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace({
        pathname: "/result/[attemptId]",
        params: { attemptId },
      });
    } catch {
      submittedRef.current = false;
      // Allow another automatic retry if the timer already expired.
      automaticSubmitTriedRef.current = false;
      setSubmitError("Your answers were not submitted. Check your connection and retry.");
    }
  }, [answers, attempt, attemptId, router, submitAttempt]);

  useEffect(() => {
    if (
      attempt &&
      answersReady &&
      remaining === 0 &&
      new Date(attempt.expiresAt).getTime() <= Date.now() &&
      !submittedRef.current &&
      !automaticSubmitTriedRef.current
    ) {
      automaticSubmitTriedRef.current = true;
      void submitNow();
    }
  }, [answersReady, attempt, remaining, submitNow]);

  const selectAnswer = (questionId: number, answer: AnswerChoice) => {
    void Haptics.selectionAsync();
    setAnswers((current) => ({ ...current, [questionId]: answer }));
  };

  const askSubmit = () => {
    setShowFinishConfirmation(true);
  };

  const currentQuestion = attempt?.questions[questionIndex];
  const answeredCount = attempt
    ? attempt.questions.filter((question) => answers[question.id] != null).length
    : 0;

  if (attemptQuery.isLoading || !answersReady) {
    return (
      <Screen>
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Preparing your practice</Text>
        </View>
      </Screen>
    );
  }

  if (!attempt || !currentQuestion) {
    return (
      <Screen>
        <View style={[styles.errorCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="cloud-offline-outline" size={28} color={colors.destructive} />
          <Text style={[styles.errorTitle, { color: colors.foreground }]}>Practice could not be opened</Text>
          <Text style={[styles.errorBody, { color: colors.mutedForeground }]}>
            The session may have expired or your connection was interrupted.
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.replace("/(tabs)/library")}
            style={[styles.primaryButton, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Back to library</Text>
          </Pressable>
        </View>
      </Screen>
    );
  }

  const timerColor = remaining < 60 ? colors.destructive : colors.foreground;
  return (
    <>
    <Screen>
      <View style={styles.topRow}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="End practice and submit answers"
          onPress={askSubmit}
          style={[styles.iconButton, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Feather name="x" size={20} color={colors.foreground} />
        </Pressable>
        <View style={styles.titleBox}>
          <Text style={[styles.examName, { color: colors.mutedForeground }]} numberOfLines={1}>{attempt.examName}</Text>
          <Text style={[styles.subjectName, { color: colors.foreground }]} numberOfLines={1}>{attempt.subjectName}</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open calculator"
          testID="open-calculator"
          onPress={() => setShowCalculator(true)}
          style={[styles.iconButton, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Ionicons name="calculator-outline" size={19} color={colors.primary} />
        </Pressable>
        <View style={[styles.timerPill, { backgroundColor: remaining < 60 ? colors.destructive : colors.secondary }]}>
          <Ionicons name="timer-outline" size={15} color={remaining < 60 ? colors.destructiveForeground : colors.primary} />
          <Text style={[styles.timerText, { color: remaining < 60 ? colors.destructiveForeground : timerColor }]}>
            {formatTime(remaining)}
          </Text>
        </View>
      </View>

      <View style={styles.progressLine}>
        <View style={[styles.progressTrack, { backgroundColor: colors.border }]}>
          <View
            style={[
              styles.progressFill,
              {
                backgroundColor: colors.primary,
                width: `${((questionIndex + 1) / attempt.questions.length) * 100}%`,
              },
            ]}
          />
        </View>
        <Text style={[styles.progressText, { color: colors.mutedForeground }]}>
          {answeredCount} of {attempt.questions.length} answered
        </Text>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.questionNav}
        accessibilityLabel="Question navigation"
      >
        {attempt.questions.map((question, index) => {
          const active = index === questionIndex;
          const answered = answers[question.id] != null;
          return (
            <Pressable
              key={question.id}
              accessibilityRole="button"
              accessibilityLabel={`Go to question ${index + 1}${answered ? ", answered" : ""}`}
              testID={`question-nav-${index + 1}`}
              onPress={() => setQuestionIndex(index)}
              style={[
                styles.questionDot,
                {
                  backgroundColor: active
                    ? colors.primary
                    : answered
                      ? colors.secondary
                      : colors.card,
                  borderColor: active ? colors.primary : colors.border,
                },
              ]}
            >
              <Text
                style={[
                  styles.questionDotText,
                  { color: active ? colors.primaryForeground : colors.foreground },
                ]}
              >
                {index + 1}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={[styles.questionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.questionCardTop}>
          <View style={[styles.questionLabel, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.questionLabelText, { color: colors.primary }]}>
              QUESTION {questionIndex + 1}
            </Text>
          </View>
          <Text style={[styles.questionCount, { color: colors.mutedForeground }]}>
            of {attempt.questions.length}
          </Text>
        </View>
        <Text style={[styles.questionBody, { color: colors.foreground }]}>{currentQuestion.body}</Text>
      </View>

      <View style={styles.answerList}>
        {choiceLetters.map((letter) => {
          const selected = answers[currentQuestion.id] === letter;
          return (
            <Pressable
              key={letter}
              accessibilityRole="radio"
              accessibilityState={{ checked: selected }}
              testID={`answer-${letter}`}
              onPress={() => selectAnswer(currentQuestion.id, letter)}
              style={({ pressed }) => [
                styles.answerOption,
                {
                  backgroundColor: selected ? colors.secondary : colors.card,
                  borderColor: selected ? colors.primary : colors.border,
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <View
                style={[
                  styles.answerLetter,
                  {
                    backgroundColor: selected ? colors.primary : colors.secondary,
                    borderColor: selected ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text style={[styles.answerLetterText, { color: selected ? colors.primaryForeground : colors.foreground }]}>
                  {letter}
                </Text>
              </View>
              <Text style={[styles.answerText, { color: colors.foreground }]}>
                {currentQuestion.options[letter]}
              </Text>
              {selected ? <Ionicons name="checkmark-circle" size={20} color={colors.primary} /> : null}
            </Pressable>
          );
        })}
      </View>

      {submitError ? (
        <Text accessibilityRole="alert" style={[styles.submitError, { color: colors.destructive }]}>
          {submitError}
        </Text>
      ) : null}

      <View style={styles.actions}>
        <Pressable
          accessibilityRole="button"
          testID="previous-question"
          disabled={questionIndex === 0}
          onPress={() => setQuestionIndex((index) => Math.max(0, index - 1))}
          style={[
            styles.secondaryButton,
            { borderColor: colors.border, backgroundColor: colors.card },
            questionIndex === 0 && styles.disabled,
          ]}
        >
          <Feather name="arrow-left" size={16} color={colors.foreground} />
          <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>Previous</Text>
        </Pressable>
        {questionIndex < attempt.questions.length - 1 ? (
          <Pressable
            accessibilityRole="button"
            testID="next-question"
            onPress={() => setQuestionIndex((index) => Math.min(attempt.questions.length - 1, index + 1))}
            style={[styles.primaryButton, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Next question</Text>
            <Feather name="arrow-right" size={16} color={colors.primaryForeground} />
          </Pressable>
        ) : (
          <Pressable
            accessibilityRole="button"
            testID="submit-practice"
            disabled={submitAttempt.isPending}
            onPress={askSubmit}
            style={[styles.primaryButton, { backgroundColor: colors.primary }, submitAttempt.isPending && styles.disabled]}
          >
            {submitAttempt.isPending ? (
              <ActivityIndicator size="small" color={colors.primaryForeground} />
            ) : (
              <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Finish practice</Text>
            )}
            <Ionicons name="checkmark" size={18} color={colors.primaryForeground} />
          </Pressable>
        )}
      </View>
      {questionIndex < attempt.questions.length - 1 ? (
        <Pressable
          accessibilityRole="button"
          testID="end-practice-early"
          onPress={askSubmit}
          style={styles.endPracticeButton}
        >
          <Text style={[styles.endPracticeText, { color: colors.mutedForeground }]}>End practice and see results</Text>
          <Feather name="arrow-right" size={13} color={colors.mutedForeground} />
        </Pressable>
      ) : null}
    </Screen>
    <Modal
      visible={showFinishConfirmation}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={() => setShowFinishConfirmation(false)}
    >
      <View style={[styles.modalBackdrop, { backgroundColor: `${colors.foreground}99` }]}>
        <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.modalIcon, { backgroundColor: colors.secondary }]}>
            <Ionicons name="checkmark-done-outline" size={23} color={colors.primary} />
          </View>
          <Text style={[styles.modalTitle, { color: colors.foreground }]}>End this practice?</Text>
          <Text style={[styles.modalBody, { color: colors.mutedForeground }]}>
            You have answered {answeredCount} of {attempt.questions.length}. Unanswered questions count as incorrect. Your score and correct answers will appear after submission.
          </Text>
          {submitError ? (
            <Text accessibilityRole="alert" style={[styles.modalError, { color: colors.destructive }]}>{submitError}</Text>
          ) : null}
          <View style={styles.modalActions}>
            <Pressable
              accessibilityRole="button"
              onPress={() => setShowFinishConfirmation(false)}
              disabled={submitAttempt.isPending}
              style={[styles.modalSecondaryButton, { borderColor: colors.border }]}
            >
              <Text style={[styles.modalButtonText, { color: colors.foreground }]}>Keep practicing</Text>
            </Pressable>
            <Pressable
              accessibilityRole="button"
              testID="confirm-submit-practice"
              onPress={() => {
                setShowFinishConfirmation(false);
                void submitNow();
              }}
              disabled={submitAttempt.isPending}
              style={[styles.modalPrimaryButton, { backgroundColor: colors.primary }, submitAttempt.isPending && styles.disabled]}
            >
              {submitAttempt.isPending ? (
                <ActivityIndicator size="small" color={colors.primaryForeground} />
              ) : (
                <Text style={[styles.modalButtonText, { color: colors.primaryForeground }]}>Submit answers</Text>
              )}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
    <PracticeCalculatorModal visible={showCalculator} onClose={() => setShowCalculator(false)} />
    </>
  );
}

function formatTime(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return hours > 0
    ? `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
    : `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

const styles = StyleSheet.create({
  loading: { minHeight: 360, alignItems: "center", justifyContent: "center", gap: 13 },
  loadingText: { fontSize: 13 },
  errorCard: { minHeight: 320, alignItems: "center", justifyContent: "center", padding: 24, borderRadius: 22, borderWidth: 1, gap: 12 },
  errorTitle: { fontSize: 18, fontWeight: "700", textAlign: "center" },
  errorBody: { fontSize: 13, lineHeight: 19, textAlign: "center" },
  topRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  iconButton: { width: 40, height: 40, borderWidth: 1, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  titleBox: { flex: 1 },
  examName: { fontSize: 10, fontWeight: "600" },
  subjectName: { fontSize: 15, fontWeight: "700", marginTop: 2 },
  timerPill: { minWidth: 78, paddingHorizontal: 10, height: 36, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5 },
  timerText: { fontSize: 12, fontWeight: "700", fontVariant: ["tabular-nums"] },
  progressLine: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 5 },
  progressTrack: { height: 5, flex: 1, overflow: "hidden", borderRadius: 4 },
  progressFill: { height: 5, borderRadius: 4 },
  progressText: { fontSize: 10, minWidth: 96, textAlign: "right" },
  questionNav: { flexDirection: "row", gap: 8, paddingVertical: 2 },
  questionDot: { width: 34, height: 34, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  questionDotText: { fontSize: 11, fontWeight: "700" },
  questionCard: { borderWidth: 1, borderRadius: 22, padding: 19, minHeight: 174, justifyContent: "center" },
  questionCardTop: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 15 },
  questionLabel: { paddingVertical: 6, paddingHorizontal: 9, borderRadius: 9 },
  questionLabelText: { fontSize: 9, letterSpacing: 1.1, fontWeight: "700" },
  questionCount: { fontSize: 10 },
  questionBody: { fontSize: 17, lineHeight: 25, fontWeight: "600" },
  answerList: { gap: 9 },
  answerOption: { minHeight: 57, borderWidth: 1, borderRadius: 16, paddingHorizontal: 11, paddingVertical: 10, flexDirection: "row", alignItems: "center", gap: 11 },
  answerLetter: { width: 32, height: 32, borderWidth: 1, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  answerLetterText: { fontSize: 12, fontWeight: "700" },
  answerText: { flex: 1, fontSize: 13, lineHeight: 18 },
  actions: { flexDirection: "row", gap: 9, marginTop: 2 },
  secondaryButton: { minHeight: 48, borderWidth: 1, paddingHorizontal: 13, borderRadius: 15, flexDirection: "row", alignItems: "center", gap: 8 },
  secondaryButtonText: { fontSize: 12, fontWeight: "700" },
  primaryButton: { minHeight: 48, flex: 1, paddingHorizontal: 15, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  primaryButtonText: { fontSize: 12, fontWeight: "700" },
  endPracticeButton: { alignSelf: "flex-end", flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 5, paddingHorizontal: 3 },
  endPracticeText: { fontSize: 11, fontWeight: "600" },
  modalBackdrop: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  modalCard: { width: "100%", maxWidth: 420, borderWidth: 1, borderRadius: 24, padding: 20, gap: 11 },
  modalIcon: { width: 46, height: 46, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  modalTitle: { fontSize: 19, fontWeight: "700" },
  modalBody: { fontSize: 13, lineHeight: 19 },
  modalError: { fontSize: 12, lineHeight: 17 },
  modalActions: { flexDirection: "row", gap: 9, marginTop: 7 },
  modalSecondaryButton: { minHeight: 46, flex: 1, paddingHorizontal: 11, borderWidth: 1, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  modalPrimaryButton: { minHeight: 46, flex: 1, paddingHorizontal: 11, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  modalButtonText: { fontSize: 11, fontWeight: "700", textAlign: "center" },
  disabled: { opacity: 0.48 },
  submitError: { fontSize: 11, lineHeight: 16 },
});
