import { type FormEvent, type ReactNode, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowRight,
  BookOpenCheck,
  Check,
  CheckCircle2,
  Clock3,
  FileSpreadsheet,
  FileText,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Plus,
  RefreshCw,
  ShieldCheck,
  Upload,
  X,
} from 'lucide-react';
import { setBaseUrl, useCreateAdminSubject, useGetCatalog, useImportQuestions, usePreviewQuestionImport, getGetCatalogQueryKey } from '@workspace/api-client-react';
import type { QuestionImportItem, QuestionImportPreview } from '@workspace/api-client-react';
import greatqMark from '@/assets/greatq-icon.png';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();
setBaseUrl(window.location.origin);

type CsvResult = { questions: QuestionImportItem[]; errors: string[]; headersOk: boolean };
type DuplicatePreviewState = { key: string; result: QuestionImportPreview };

function parseCsv(source: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"' && source[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"' && cell.trim().length === 0) {
      cell = '';
      quoted = true;
    } else if (char === ',') {
      row.push(cell);
      cell = '';
    } else if (char === '\n') {
      row.push(cell.replace(/\r$/, ''));
      if (row.some((value) => value.trim() !== '')) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  if (quoted) throw new Error('A quoted field is not closed. Check the CSV quoting around the last row.');
  if (cell.length || row.length) {
    row.push(cell.replace(/\r$/, ''));
    if (row.some((value) => value.trim() !== '')) rows.push(row);
  }
  return rows;
}

function inspectCsv(source: string): CsvResult {
  const errors: string[] = [];
  try {
    const rows = parseCsv(source);
    if (!rows.length) return { questions: [], errors: ['The CSV is empty. Add a header row and at least one question.'], headersOk: false };
    const headers = rows[0].map((value) => value.trim().toLowerCase());
    const required = ['body', 'option_a', 'option_b', 'option_c', 'option_d', 'answer'];
    const missing = required.filter((header) => !headers.includes(header));
    if (missing.length) return { questions: [], errors: [`Missing required column${missing.length > 1 ? 's' : ''}: ${missing.join(', ')}.`], headersOk: false };
    const index = (name: string) => headers.indexOf(name);
    const questions: QuestionImportItem[] = [];
    rows.slice(1).forEach((values, offset) => {
      const line = offset + 2;
      const value = (key: string) => (values[index(key)] ?? '').trim();
      const body = value('body');
      const options = {
        A: value('option_a'),
        B: value('option_b'),
        C: value('option_c'),
        D: value('option_d'),
      };
      const rawAnswer = value('answer').toUpperCase();
      const rawYear = value('year');
      const rowErrors: string[] = [];
      if (!body) rowErrors.push('question body is blank');
      (['A', 'B', 'C', 'D'] as const).forEach((letter) => {
        if (!options[letter]) rowErrors.push(`option ${letter} is blank`);
      });
      if (!['A', 'B', 'C', 'D'].includes(rawAnswer)) rowErrors.push('answer must be A, B, C, or D');
      let year: number | undefined;
      if (rawYear) {
        year = Number(rawYear);
        if (!Number.isInteger(year) || year < 1900 || year > 2200) rowErrors.push('year must be a whole number from 1900 to 2200');
      }
      if (rowErrors.length) errors.push(`Row ${line}: ${rowErrors.join('; ')}.`);
      else {
        const explanation = value('explanation');
        questions.push({
          body,
          options,
          answer: rawAnswer as 'A' | 'B' | 'C' | 'D',
          ...(explanation ? { explanation } : {}),
          ...(year ? { year } : {}),
        });
      }
    });
    if (rows.length < 2) errors.push('No question rows found. Add at least one row below the headers.');
    if (rows.length > 501) errors.push(`This batch has ${rows.length - 1} rows. A batch can contain at most 500 questions.`);
    if (questions.length > 500) errors.push('A batch can contain at most 500 questions.');
    return { questions, errors, headersOk: true };
  } catch (error) {
    return { questions: [], errors: [error instanceof Error ? error.message : 'Could not read this CSV file.'], headersOk: false };
  }
}

function formatUpdated(value: string | null | undefined): string {
  if (!value) return 'Not yet updated';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently';
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function getImportErrorMessage(error: unknown): string {
  if (error && typeof error === 'object') {
    const apiError = error as { data?: unknown; status?: number; message?: string };
    if (apiError.data && typeof apiError.data === 'object') {
      const data = apiError.data as { error?: unknown; message?: unknown };
      if (typeof data.error === 'string' && data.error.trim()) return data.error;
      if (typeof data.message === 'string' && data.message.trim()) return data.message;
    }
    if (apiError.status === 401) {
      return 'The admin upload token was rejected. Check that it matches ADMIN_UPLOAD_TOKEN.';
    }
    if (apiError.status === 503) {
      return 'Admin uploads are not configured on the API server. Check the ADMIN_UPLOAD_TOKEN secret.';
    }
    if (apiError.status === 413) {
      return 'This upload is too large. Split the CSV into smaller batches and retry.';
    }
    if (apiError.message === 'Failed to fetch') {
      return 'Could not reach the GreatQ question server. Check your connection and try again.';
    }
    if (typeof apiError.message === 'string' && apiError.message.trim()) {
      return apiError.message;
    }
  }
  return 'The import could not be completed. Check the CSV and try again.';
}

function Home() {
  const queryClient = useQueryClient();
  const catalog = useGetCatalog({ query: { refetchOnWindowFocus: true } });
  const [examName, setExamName] = useState('');
  const [subjectName, setSubjectName] = useState('');
  const [durationMin, setDurationMin] = useState('60');
  const [token, setToken] = useState('');
  const [csvText, setCsvText] = useState('');
  const [fileName, setFileName] = useState('');
  const [dragging, setDragging] = useState(false);
  const [resultMessage, setResultMessage] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [duplicatePreview, setDuplicatePreview] = useState<DuplicatePreviewState | null>(null);
  const [duplicatePreviewMessage, setDuplicatePreviewMessage] = useState('');
  const [importDraftVersion, setImportDraftVersion] = useState(0);
  const [newSubjectExam, setNewSubjectExam] = useState('');
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectDuration, setNewSubjectDuration] = useState('60');
  const [newSubjectToken, setNewSubjectToken] = useState('');
  const [newSubjectMessage, setNewSubjectMessage] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const validation = useMemo(() => (csvText ? inspectCsv(csvText) : null), [csvText]);
  const importPayload = useMemo(() => validation ? ({
    examName: examName.trim(),
    subjectName: subjectName.trim(),
    durationMin: Number(durationMin),
    questions: validation.questions,
  }) : null, [durationMin, examName, subjectName, validation]);
  const previewKey = useMemo(
    () => importPayload ? `${importDraftVersion}:${JSON.stringify(importPayload)}` : '',
    [importDraftVersion, importPayload],
  );
  const subjectCreator = useCreateAdminSubject({
    request: { headers: newSubjectToken.trim() ? { Authorization: `Bearer ${newSubjectToken.trim()}` } : {} },
  });
  const importer = useImportQuestions({
    request: { headers: token.trim() ? { Authorization: `Bearer ${token.trim()}` } : {} },
  });
  const duplicateChecker = usePreviewQuestionImport({
    request: { headers: token.trim() ? { Authorization: `Bearer ${token.trim()}` } : {} },
  });
  const data = catalog.data;
  const examCount = data?.exams.length ?? 0;
  const questionCount = data?.totalQuestions ?? 0;
  const subjectCount = data?.totalSubjects ?? 0;
  const durationValue = Number(durationMin);
  const formErrors = [
    !examName.trim() ? 'Enter an exam name.' : '',
    !subjectName.trim() ? 'Enter a subject name.' : '',
    !Number.isInteger(durationValue) || durationValue < 1 || durationValue > 300 ? 'Duration must be a whole number from 1 to 300 minutes.' : '',
    !token.trim() ? 'Enter the admin upload token.' : '',
    !validation ? 'Choose a CSV file to continue.' : '',
  ].filter(Boolean);
  const canCheckDuplicates = formErrors.length === 0 && validation !== null && validation.errors.length === 0 && validation.questions.length > 0 && !importer.isPending && !duplicateChecker.isPending;
  const matchingPreview = previewKey && duplicatePreview?.key === previewKey ? duplicatePreview.result : null;
  const canImport = Boolean(matchingPreview && matchingPreview.newQuestionCount > 0 && !importer.isPending && !duplicateChecker.isPending);
  const existingDuplicateCount = matchingPreview?.duplicates.filter((duplicate) => duplicate.source === 'question_bank').length ?? 0;
  const csvDuplicateCount = matchingPreview?.duplicates.filter((duplicate) => duplicate.source === 'csv').length ?? 0;
  const newSubjectDurationValue = Number(newSubjectDuration);
  const canCreateSubject = Boolean(
    newSubjectExam.trim() &&
    newSubjectName.trim() &&
    Number.isInteger(newSubjectDurationValue) &&
    newSubjectDurationValue >= 1 &&
    newSubjectDurationValue <= 300 &&
    newSubjectToken.trim() &&
    !subjectCreator.isPending,
  );

  function clearDuplicatePreview() {
    setDuplicatePreview(null);
    setDuplicatePreviewMessage('');
    setImportDraftVersion((version) => version + 1);
  }

  function loadFile(file?: File) {
    if (!file) return;
    clearDuplicatePreview();
    setShowResult(false);
    setResultMessage('');
    if (!file.name.toLowerCase().endsWith('.csv') && file.type !== 'text/csv') {
      setCsvText('');
      setFileName('');
      setResultMessage('Select a .csv file to upload.');
      setShowResult(true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setCsvText(typeof reader.result === 'string' ? reader.result.replace(/^\uFEFF/, '') : '');
      setFileName(file.name);
    };
    reader.onerror = () => {
      setResultMessage('We could not read that file. Try saving a fresh CSV and upload it again.');
      setShowResult(true);
    };
    reader.readAsText(file);
  }

  function downloadTemplate() {
    const template = 'body,option_a,option_b,option_c,option_d,answer,explanation,year\n"What is the capital of France?","Paris","Lyon","Nice","Lille","A","Paris is the capital city.",2022\n';
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'greatq-question-template.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  function submitImport() {
    if (!canImport || !importPayload) return;
    setShowResult(false);
    importer.mutate({
      data: importPayload,
    }, {
      onSuccess: (result) => {
        void queryClient.invalidateQueries({ queryKey: getGetCatalogQueryKey() });
        setResultMessage(`${result.added} new questions added to ${result.examName} · ${result.subjectName}; ${result.skippedDuplicates} duplicate rows skipped. The catalog now contains ${result.totalQuestions.toLocaleString()} questions.`);
        setShowResult(true);
        clearDuplicatePreview();
        setCsvText('');
        setFileName('');
        if (fileInput.current) fileInput.current.value = '';
        setToken('');
      },
      onError: (error) => {
        setResultMessage(getImportErrorMessage(error));
        setShowResult(true);
      },
    });
  }

  function previewImport() {
    if (!canCheckDuplicates || !importPayload) return;
    setShowResult(false);
    setDuplicatePreview(null);
    setDuplicatePreviewMessage('');
    duplicateChecker.mutate({ data: importPayload }, {
      onSuccess: (result) => setDuplicatePreview({ key: previewKey, result }),
      onError: (error) => setDuplicatePreviewMessage(getImportErrorMessage(error)),
    });
  }

  function submitNewSubject(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canCreateSubject) return;
    setNewSubjectMessage('');
    subjectCreator.mutate({
      data: {
        examName: newSubjectExam.trim(),
        subjectName: newSubjectName.trim(),
        durationMin: newSubjectDurationValue,
      },
    }, {
      onSuccess: (subject) => {
        void queryClient.invalidateQueries({ queryKey: getGetCatalogQueryKey() });
        setExamName(subject.examName);
        setSubjectName(subject.name);
        setDurationMin(String(subject.durationMin));
        setNewSubjectMessage(`${subject.name} is ready under ${subject.examName}. The import form is set to this subject.`);
        setNewSubjectName('');
        setNewSubjectToken('');
      },
      onError: (error) => setNewSubjectMessage(getImportErrorMessage(error)),
    });
  }

  const subjects = data?.exams.flatMap((exam) => exam.subjects.map((subject) => ({ exam: exam.name, name: subject.name, count: subject.questionCount }))) ?? [];

  return (
    <div className="min-h-[100dvh] bg-[#F5F6EF]">
      <header className="sticky top-0 z-20 border-b border-[#dce2d5] bg-[#f8f9f3]/95 backdrop-blur-md">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-4 sm:px-7 lg:px-10">
          <div className="flex items-center gap-3">
            <img src={greatqMark} alt="GreatQ" className="h-11 w-11 rounded-xl object-cover shadow-sm" data-testid="img-greatq-brand" />
            <div className="leading-tight">
              <div className="font-display text-[19px] font-extrabold tracking-[-0.045em] text-[#20352A]">GreatQ <span className="font-sans text-[13px] font-semibold tracking-[.02em] text-[#718075]">Admin</span></div>
              <div className="mt-1 text-[10px] font-semibold uppercase tracking-[.17em] text-[#879188]">Question bank operations</div>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-[#dde4d9] bg-white/70 px-3 py-2 text-[11px] font-semibold tracking-[.04em] text-[#536a5b]">
            <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#8eaa79] opacity-50" /><span className="relative inline-flex h-2 w-2 rounded-full bg-[#688a57]" /></span>
            STAFF WORKSPACE
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1440px] px-4 pb-12 pt-7 sm:px-7 lg:px-10 lg:pt-10">
        <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div className="page-enter">
            <div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.17em] text-[#718075]">
              <span className="h-px w-7 bg-[#D4AE4F]" /> Content administration
            </div>
            <h1 className="font-display text-[32px] font-extrabold leading-[1.08] tracking-[-.045em] text-[#20352A] sm:text-[40px]">Welcome back. <span className="text-[#52755C]">Let’s keep the bank current.</span></h1>
            <p className="mt-3 max-w-2xl text-[14px] leading-6 text-[#6d796f]">Upload a verified question batch and keep GreatQ ready for every study session.</p>
          </div>
          <div className="page-enter delay-1 flex items-center gap-2 self-start rounded-xl border border-[#dce2d5] bg-[#fbfcf7] px-3.5 py-3 text-[12px] text-[#647268] md:self-auto">
            <Clock3 size={15} className="text-[#718b72]" />
            <span>Catalog updated</span>
            <span className="font-semibold text-[#354d3d]" data-testid="text-catalog-updated">{formatUpdated(data?.lastUpdatedAt)}</span>
          </div>
        </div>

        <section className="mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4" aria-label="Catalog overview">
          <Metric label="Questions in bank" value={catalog.isLoading ? '—' : questionCount.toLocaleString()} detail="Across all subjects" icon={<BookOpenCheck size={17} />} index={0} />
          <Metric label="Subjects" value={catalog.isLoading ? '—' : subjectCount.toLocaleString()} detail="Ready for practice" icon={<FileText size={17} />} index={1} />
          <Metric label="Exam collections" value={catalog.isLoading ? '—' : examCount.toLocaleString()} detail="Organized by exam" icon={<FileSpreadsheet size={17} />} index={2} />
          <div className="page-enter delay-2 relative overflow-hidden rounded-2xl bg-[#285640] p-4 text-[#f4f5e9] sm:p-5">
            <div className="absolute -right-7 -top-10 h-32 w-32 rounded-full border border-white/10" />
            <div className="absolute -right-1 -top-2 h-20 w-20 rounded-full border border-white/10" />
            <div className="relative flex items-start justify-between">
              <div><div className="text-[11px] font-semibold uppercase tracking-[.12em] text-[#c9d6c7]">Ready to import</div><div className="mt-2 font-display text-[23px] font-bold tracking-[-.04em]">{validation?.questions.length ?? '—'} <span className="font-sans text-[13px] font-medium tracking-normal text-[#d0dbcd]">questions</span></div></div>
              <div className="rounded-xl bg-[#ffffff]/10 p-2 text-[#e0c26e]"><ShieldCheck size={18} /></div>
            </div>
            <div className="relative mt-3 h-1.5 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-[#D4AE4F] transition-all" style={{ width: `${Math.min(((validation?.questions.length ?? 0) / 500) * 100, 100)}%` }} /></div>
          </div>
        </section>

        {catalog.isError && <div className="mb-6 flex items-center justify-between gap-4 rounded-xl border border-[#e7c6bd] bg-[#fff7f4] px-4 py-3 text-sm text-[#8d4236]" role="alert">
          <span className="flex items-center gap-2"><AlertCircle size={16} /> Catalog totals could not be loaded.</span>
          <button onClick={() => void catalog.refetch()} className="focus-ring flex items-center gap-1.5 rounded-lg px-2 py-1 font-semibold hover:bg-[#fae8e2]" data-testid="button-retry-catalog"><RefreshCw size={14} /> Retry</button>
        </div>}

        <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1.45fr)_minmax(320px,.75fr)]">
          <section className="page-enter overflow-hidden rounded-[20px] border border-[#dce2d5] bg-[#fffefa] shadow-[0_8px_30px_rgba(45,68,48,.045)]">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#e8ebe3] px-5 py-5 sm:px-7">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf0e6] text-[#285640]"><Upload size={17} /></div>
                <div><h2 className="font-display text-[19px] font-bold tracking-[-.025em] text-[#20352A]">Import a question batch</h2><p className="mt-1 text-[12px] text-[#7b867c]">Select its destination, then validate your CSV before importing.</p></div>
              </div>
              <button type="button" onClick={downloadTemplate} className="focus-ring flex items-center gap-2 rounded-lg border border-[#dce2d5] px-3 py-2 text-[11px] font-semibold text-[#47624e] transition-colors hover:border-[#9eb19c] hover:bg-[#f4f7f0]" data-testid="button-download-template"><ArrowDownToLine size={14} /> CSV template</button>
            </div>

            <form
              className="space-y-6 px-5 py-6 sm:px-7"
              onSubmit={(event) => {
                event.preventDefault();
                submitImport();
              }}
            >
              <div className="grid gap-4 sm:grid-cols-[1fr_1fr_150px]">
                <Field label="Exam name" hint="Choose or enter an exam">
                  <input list="exam-options" value={examName} onChange={(event) => { setExamName(event.target.value); clearDuplicatePreview(); }} placeholder="e.g. National Senior Certificate" className="form-input" data-testid="input-exam-name" />
                  <datalist id="exam-options">{data?.exams.map((exam) => <option key={exam.id} value={exam.name} />)}</datalist>
                </Field>
                <Field label="Subject name" hint="Choose or enter a subject">
                  <input list="subject-options" value={subjectName} onChange={(event) => { setSubjectName(event.target.value); clearDuplicatePreview(); }} placeholder="e.g. Mathematics" className="form-input" data-testid="input-subject-name" />
                  <datalist id="subject-options">{subjects.map((subject, index) => <option key={`${subject.exam}-${subject.name}-${index}`} value={subject.name}>{subject.exam}</option>)}</datalist>
                </Field>
                <Field label="Duration" hint="Minutes">
                  <div className="relative"><input type="number" min="1" max="300" step="1" value={durationMin} onChange={(event) => { setDurationMin(event.target.value); clearDuplicatePreview(); }} className="form-input pr-12" data-testid="input-duration" /><span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-[#89928a]">min</span></div>
                </Field>
              </div>

              <div>
                <div className="mb-2 flex items-end justify-between gap-3">
                  <div><div className="text-[12px] font-bold text-[#344d3b]">Question file</div><div className="mt-0.5 text-[11px] text-[#89928a]">CSV · up to 500 questions per batch</div></div>
                  {fileName && <button onClick={() => { clearDuplicatePreview(); setCsvText(''); setFileName(''); if (fileInput.current) fileInput.current.value = ''; }} className="focus-ring flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-[#7b867c] hover:bg-[#f1f3ec]" data-testid="button-remove-file"><X size={13} /> Remove file</button>}
                </div>
                <div
                  className={`drop-zone ${dragging ? 'dragging' : ''} rounded-2xl border border-dashed border-[#cbd5c7] bg-[#f8f9f4] px-4 py-6 text-center sm:py-7`}
                  onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={(event) => { event.preventDefault(); setDragging(false); loadFile(event.dataTransfer.files[0]); }}
                  data-testid="dropzone-csv"
                >
                  <input ref={fileInput} type="file" accept=".csv,text/csv" className="hidden" onChange={(event) => loadFile(event.target.files?.[0])} data-testid="input-csv-file" />
                  {fileName ? <div className="mx-auto flex max-w-lg items-center justify-center gap-3 text-left">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e6eee2] text-[#285640]"><FileSpreadsheet size={20} /></div>
                    <div className="min-w-0 flex-1"><div className="truncate text-[13px] font-semibold text-[#344d3b]" data-testid="text-csv-filename">{fileName}</div><div className="mt-1 text-[11px] text-[#818b82]">{validation?.questions.length ?? 0} valid question rows detected</div></div>
                    {validation?.errors.length === 0 ? <CheckCircle2 size={20} className="shrink-0 text-[#5b815e]" /> : <AlertCircle size={20} className="shrink-0 text-[#b36b4e]" />}
                  </div> : <>
                    <div className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-[14px] bg-[#eaf0e6] text-[#285640]"><ArrowDownToLine size={19} /></div>
                    <div className="text-[13px] font-semibold text-[#344d3b]">Drop your CSV file here</div>
                    <div className="mt-1 text-[11px] text-[#8b948b]">or browse from your computer</div>
                    <button type="button" onClick={() => fileInput.current?.click()} className="focus-ring mt-4 rounded-lg bg-[#285640] px-4 py-2 text-[11px] font-semibold text-white transition-colors hover:bg-[#1e4835]" data-testid="button-browse-csv">Browse files</button>
                  </>}
                </div>
              </div>

              {validation && <ValidationPanel validation={validation} />}

              {duplicatePreviewMessage && <div className="flex gap-3 rounded-xl border border-[#e9cfc7] bg-[#fff7f4] p-4 text-[#8d4236]" role="alert" data-testid="status-duplicate-preview-error">
                <AlertCircle className="mt-0.5 shrink-0" size={17} />
                <div><div className="text-[12px] font-bold">Duplicate check needs attention</div><div className="mt-1 text-[12px] leading-5">{duplicatePreviewMessage}</div></div>
              </div>}

              {matchingPreview && <div className={`rounded-xl border p-4 ${matchingPreview.duplicateCount ? 'border-[#ead8c3] bg-[#fff9f2]' : 'border-[#cbdcc8] bg-[#f1f7ef]'}`} role="status" data-testid="panel-duplicate-preview">
                <div className="flex items-start gap-3">
                  {matchingPreview.duplicateCount ? <AlertCircle className="mt-0.5 shrink-0 text-[#a66e32]" size={17} /> : <CheckCircle2 className="mt-0.5 shrink-0 text-[#5b815e]" size={17} />}
                  <div className="min-w-0">
                    <div className="text-[12px] font-bold text-[#344d3b]">{matchingPreview.duplicateCount ? `${matchingPreview.duplicateCount} duplicate ${matchingPreview.duplicateCount === 1 ? 'row' : 'rows'} will be skipped` : 'No duplicates found'}</div>
                    <div className="mt-1 text-[11px] leading-5 text-[#69786b]">
                      {matchingPreview.newQuestionCount} new questions will be added
                      {existingDuplicateCount ? ` · ${existingDuplicateCount} already in the question bank` : ''}
                      {csvDuplicateCount ? ` · ${csvDuplicateCount} repeated within this CSV` : ''}.
                    </div>
                    {matchingPreview.duplicates.length > 0 && <ul className="mt-2 space-y-1 text-[11px] leading-4 text-[#806344]" data-testid="list-duplicate-rows">
                      {matchingPreview.duplicates.slice(0, 12).map((duplicate) => <li key={duplicate.rowNumber} data-testid={`text-duplicate-row-${duplicate.rowNumber}`}>
                        CSV row {duplicate.rowNumber}: {duplicate.source === 'question_bank' ? 'already in this subject' : `repeats row ${duplicate.duplicateOfRow}`}
                      </li>)}
                      {matchingPreview.duplicates.length > 12 && <li>And {matchingPreview.duplicates.length - 12} more duplicate rows.</li>}
                    </ul>}
                  </div>
                </div>
              </div>}

              <div className="rounded-xl border border-[#e5e8df] bg-[#f8f9f4] p-4">
                <div className="mb-3 flex items-center gap-2 text-[12px] font-bold text-[#344d3b]"><LockKeyhole size={15} className="text-[#668267]" /> Secure upload authorization</div>
                <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
                  <div className="min-w-0 flex-1">
                    <label htmlFor="admin-token" className="mb-1.5 block text-[11px] font-medium text-[#6d796f]">Admin upload token</label>
                    <div className="relative">
                      <KeyRound size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#91a092]" />
                      <input id="admin-token" type="password" autoComplete="off" value={token} onChange={(event) => { setToken(event.target.value); clearDuplicatePreview(); }} placeholder="Enter your ADMIN_UPLOAD_TOKEN" className="form-input pl-9 font-mono text-[12px]" data-testid="input-admin-token" />
                    </div>
                    <p className="mt-1.5 text-[10px] leading-4 text-[#8a948b]">Held only for this session and sent securely with the import request.</p>
                  </div>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <button type="button" onClick={previewImport} disabled={!canCheckDuplicates} className="focus-ring flex h-[42px] shrink-0 items-center justify-center gap-2 rounded-xl border border-[#b8c9b6] bg-white px-4 text-[11px] font-bold text-[#365c40] transition-colors hover:bg-[#f3f7f0] disabled:cursor-not-allowed disabled:border-[#dce2d5] disabled:text-[#9aa39a] sm:min-w-[142px]" data-testid="button-check-duplicates">
                      {duplicateChecker.isPending ? <><LoaderCircle size={14} className="animate-spin" /> Checking</> : <><ShieldCheck size={14} /> Check duplicates</>}
                    </button>
                    <button type="submit" disabled={!canImport} className="focus-ring flex h-[42px] shrink-0 items-center justify-center gap-2 rounded-xl bg-[#285640] px-4 text-[11px] font-bold text-white shadow-[0_3px_8px_rgba(40,86,64,.15)] transition-all hover:bg-[#1e4835] active:translate-y-px disabled:cursor-not-allowed disabled:bg-[#c4cec1] disabled:shadow-none sm:min-w-[160px]" data-testid="button-import-questions">
                      {importer.isPending ? <><LoaderCircle size={14} className="animate-spin" /> Importing</> : <>Import {matchingPreview ? matchingPreview.newQuestionCount : 'new'} questions <ArrowRight size={14} /></>}
                    </button>
                  </div>
                </div>
              </div>

              {showResult && <div className={`flex gap-3 rounded-xl border p-4 ${importer.isError || resultMessage.includes('Select a .csv') ? 'border-[#e9cfc7] bg-[#fff7f4] text-[#8d4236]' : 'border-[#cbdcc8] bg-[#f1f7ef] text-[#355d3d]'}`} role="status" data-testid="status-import-result">
                {importer.isError || resultMessage.includes('Select a .csv') ? <AlertCircle className="mt-0.5 shrink-0" size={17} /> : <CheckCircle2 className="mt-0.5 shrink-0" size={17} />}
                <div><div className="text-[12px] font-bold">{importer.isError || resultMessage.includes('Select a .csv') ? 'Import needs attention' : 'Batch imported'}</div><div className="mt-1 text-[12px] leading-5">{resultMessage}</div></div>
              </div>}
            </form>
            <div className="flex items-center gap-2 border-t border-[#e8ebe3] px-5 py-3.5 text-[10px] text-[#89928a] sm:px-7"><ShieldCheck size={14} className="text-[#799177]" /> CSV is validated in your browser before any question data is sent.</div>
          </section>

          <aside className="page-enter delay-1 space-y-5">
            <section className="overflow-hidden rounded-[20px] border border-[#dce2d5] bg-[#fffefa] shadow-[0_8px_30px_rgba(45,68,48,.035)]">
              <div className="flex items-start gap-3 border-b border-[#e8ebe3] px-5 py-4">
                <div className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf0e6] text-[#285640]"><Plus size={17} /></div>
                <div><h2 className="font-display text-[16px] font-bold tracking-[-.02em] text-[#20352A]">Add a subject</h2><p className="mt-1 text-[11px] leading-4 text-[#89928a]">Create a subject before uploading its questions.</p></div>
              </div>
              <form className="space-y-3 p-5" onSubmit={submitNewSubject} data-testid="form-create-subject">
                <div>
                  <label htmlFor="new-subject-exam" className="mb-1.5 block text-[11px] font-bold text-[#344d3b]">Exam collection</label>
                  <input id="new-subject-exam" list="admin-exam-options" value={newSubjectExam} onChange={(event) => { setNewSubjectExam(event.target.value); setNewSubjectMessage(''); }} placeholder="e.g. University Entrance Exam" className="form-input" data-testid="input-new-subject-exam" />
                  <datalist id="admin-exam-options">{data?.exams.map((exam) => <option key={exam.id} value={exam.name} />)}</datalist>
                </div>
                <div className="grid grid-cols-[minmax(0,1fr)_92px] gap-3">
                  <div>
                    <label htmlFor="new-subject-name" className="mb-1.5 block text-[11px] font-bold text-[#344d3b]">Subject name</label>
                    <input id="new-subject-name" value={newSubjectName} onChange={(event) => { setNewSubjectName(event.target.value); setNewSubjectMessage(''); }} placeholder="e.g. Chemistry" className="form-input" data-testid="input-new-subject-name" />
                  </div>
                  <div>
                    <label htmlFor="new-subject-duration" className="mb-1.5 block text-[11px] font-bold text-[#344d3b]">Minutes</label>
                    <input id="new-subject-duration" type="number" min="1" max="300" step="1" value={newSubjectDuration} onChange={(event) => { setNewSubjectDuration(event.target.value); setNewSubjectMessage(''); }} className="form-input" data-testid="input-new-subject-duration" />
                  </div>
                </div>
                <div>
                  <label htmlFor="new-subject-token" className="mb-1.5 block text-[11px] font-bold text-[#344d3b]">Admin upload token</label>
                  <input id="new-subject-token" type="password" autoComplete="off" value={newSubjectToken} onChange={(event) => { setNewSubjectToken(event.target.value); setNewSubjectMessage(''); }} placeholder="Enter your admin token" className="form-input font-mono" data-testid="input-new-subject-token" />
                </div>
                <button type="submit" disabled={!canCreateSubject} className="focus-ring flex h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-[#285640] px-4 text-[11px] font-bold text-white transition-colors hover:bg-[#1e4835] disabled:cursor-not-allowed disabled:bg-[#c4cec1]" data-testid="button-create-subject">
                  {subjectCreator.isPending ? <><LoaderCircle size={14} className="animate-spin" /> Saving subject</> : <><Plus size={14} /> Add subject</>}
                </button>
                {newSubjectMessage ? <div className={`rounded-lg px-3 py-2 text-[11px] leading-4 ${subjectCreator.isError ? 'bg-[#fff7f4] text-[#8d4236]' : 'bg-[#f1f7ef] text-[#355d3d]'}`} role={subjectCreator.isError ? 'alert' : 'status'} data-testid="status-create-subject">{newSubjectMessage}</div> : null}
                <p className="text-[10px] leading-4 text-[#89928a]">The subject will appear in the student library after questions are uploaded.</p>
              </form>
            </section>
            <section className="overflow-hidden rounded-[20px] border border-[#dce2d5] bg-[#fffefa] shadow-[0_8px_30px_rgba(45,68,48,.035)]">
              <div className="flex items-center justify-between border-b border-[#e8ebe3] px-5 py-4">
                <div><h2 className="font-display text-[16px] font-bold tracking-[-.02em] text-[#20352A]">Catalog snapshot</h2><p className="mt-1 text-[11px] text-[#89928a]">Current question coverage</p></div>
                <div className="rounded-lg bg-[#f0f3eb] p-2 text-[#547257]"><BookOpenCheck size={16} /></div>
              </div>
              {catalog.isLoading ? <div className="space-y-3 p-5" aria-label="Loading catalog"><div className="h-4 w-3/4 animate-pulse rounded bg-[#e8ece4]" /><div className="h-4 w-full animate-pulse rounded bg-[#e8ece4]" /><div className="h-4 w-2/3 animate-pulse rounded bg-[#e8ece4]" /></div> : catalog.isError ? <div className="p-5 text-[12px] text-[#78847a]">Catalog details are temporarily unavailable.</div> : data?.exams.length ? <div className="divide-y divide-[#edf0e9]">
                {data.exams.slice(0, 6).map((exam) => <div key={exam.id} className="px-5 py-4" data-testid={`row-exam-${exam.id}`}>
                  <div className="flex items-center justify-between gap-3"><div className="truncate text-[12px] font-bold text-[#344d3b]">{exam.name}</div><div className="shrink-0 font-mono text-[10px] text-[#77857a]">{exam.subjects.reduce((sum, subject) => sum + subject.questionCount, 0).toLocaleString()} Q</div></div>
                  <div className="mt-2 flex flex-wrap gap-1.5">{exam.subjects.slice(0, 4).map((subject) => <span key={subject.id} className="rounded-md bg-[#f2f4ee] px-2 py-1 text-[10px] text-[#68796b]">{subject.name}<span className="ml-1.5 font-mono text-[#8e9b8e]">{subject.questionCount}</span></span>)}{exam.subjects.length > 4 && <span className="px-1 py-1 text-[10px] text-[#829084]">+{exam.subjects.length - 4} more</span>}</div>
                </div>)}
                {data.exams.length > 6 && <div className="px-5 py-3 text-[10px] font-medium text-[#809081]">{data.exams.length - 6} more exam collections</div>}
              </div> : <div className="px-5 py-8 text-center"><div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-[#f0f3eb] text-[#789078]"><BookOpenCheck size={17} /></div><div className="text-[12px] font-semibold text-[#526451]">No questions yet</div><p className="mt-1 text-[11px] text-[#8a948b]">Your first successful batch will appear here.</p></div>}
            </section>
            <section className="relative overflow-hidden rounded-[18px] bg-[#e9eddf] p-5">
              <div className="absolute -right-10 -top-14 h-36 w-36 rounded-full border border-[#d6dfce]" />
              <div className="relative flex gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#f7f7ef] text-[#4f7055]"><FileText size={16} /></div>
                <div><div className="text-[12px] font-bold text-[#344d3b]">Keep your CSV tidy</div><p className="mt-1.5 text-[11px] leading-[1.65] text-[#6f7c70]">Required columns: body, option_a, option_b, option_c, option_d, answer. Explanation and year are optional. Extra columns are ignored.</p><button onClick={downloadTemplate} className="focus-ring mt-3 inline-flex items-center gap-1.5 text-[11px] font-bold text-[#3b6246] hover:text-[#20352A]" data-testid="button-download-template-tip">Get the template <ArrowRight size={13} /></button></div>
              </div>
            </section>
          </aside>
        </div>
        <footer className="mt-9 flex flex-col gap-2 border-t border-[#dce2d5] pt-4 text-[10px] text-[#89928a] sm:flex-row sm:items-center sm:justify-between">
          <span>GreatQ question bank · Staff administration</span>
          <span>Changes are reflected in the student catalog after import.</span>
        </footer>
      </main>
    </div>
  );
}

function Metric({ label, value, detail, icon, index }: { label: string; value: string; detail: string; icon: ReactNode; index: number }) {
  return <div className={`page-enter ${index ? `delay-${index}` : ''} rounded-2xl border border-[#dce2d5] bg-[#fffefa] p-4 sm:p-5`}>
    <div className="flex items-center justify-between gap-2"><span className="text-[11px] font-semibold text-[#78847a]">{label}</span><span className="flex h-8 w-8 items-center justify-center rounded-[10px] bg-[#edf2e9] text-[#4b6b52]">{icon}</span></div>
    <div className="mt-2 font-display text-[28px] font-extrabold leading-none tracking-[-.045em] text-[#20352A]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</div>
    <div className="mt-2 text-[10px] text-[#8b948b]">{detail}</div>
  </div>;
}

function Field({ label, hint, children }: { label: string; hint: string; children: ReactNode }) {
  return <div className="min-w-0"><label className="mb-1.5 block text-[12px] font-bold text-[#344d3b]">{label}</label>{children}<div className="mt-1.5 text-[10px] text-[#89928a]">{hint}</div></div>;
}

function ValidationPanel({ validation }: { validation: CsvResult }) {
  const valid = validation.errors.length === 0 && validation.questions.length > 0;
  return <div className={`rounded-xl border px-4 py-3.5 ${valid ? 'border-[#d4e0d0] bg-[#f4f8f1]' : 'border-[#ead8c3] bg-[#fff9f2]'}`} data-testid="panel-csv-validation">
    <div className="flex items-start gap-3">
      <div className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${valid ? 'bg-[#e2eee0] text-[#4f7652]' : 'bg-[#f6ead8] text-[#a66e32]'}`}>{valid ? <Check size={15} /> : <AlertCircle size={15} />}</div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center justify-between gap-2"><div className="text-[12px] font-bold text-[#3c5140]">{valid ? 'CSV looks good' : 'Review the CSV before importing'}</div><div className="font-mono text-[10px] text-[#78847a]">{validation.questions.length} / 500 valid</div></div>
        {validation.errors.length ? <ul className="mt-2 space-y-1 text-[11px] leading-4 text-[#8d5d3a]" data-testid="list-csv-errors">{validation.errors.slice(0, 12).map((error, index) => <li key={`${error}-${index}`}>• {error}</li>)}{validation.errors.length > 12 && <li>And {validation.errors.length - 12} more issues. Fix these in the CSV and choose the file again.</li>}</ul> : <p className="mt-1 text-[11px] text-[#738174]">All required columns and question rows are valid. Ready for secure import.</p>}
      </div>
    </div>
  </div>;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
