---
name: Expo DevTools system libraries
description: Optional React Native DevTools can fail on missing desktop libraries even while the Expo app is healthy.
---

A missing shared library in React Native DevTools is not, by itself, evidence that the Expo app is broken. Metro and the app preview can continue to work even when the desktop debugger cannot launch. Installing one missing library may reveal another dependency in the desktop Electron/GTK chain.

**Why:** During GreatQ verification, adding missing runtime libraries exposed another GTK dependency while Metro and the app preview remained healthy.

**How to apply:** Check Metro bundling, the Expo preview, and API health separately. Only install the full desktop dependency chain when the DevTools debugger itself is needed.
